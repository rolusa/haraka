package core

import (
	"context"
	"fmt"
	"sync"
	"sync/atomic"
	"time"

	"__MODULE_PLACEHOLDER__/config"
	"__MODULE_PLACEHOLDER__/email"
	"__MODULE_PLACEHOLDER__/injector"
	"__MODULE_PLACEHOLDER__/reader"
	"__MODULE_PLACEHOLDER__/types"
)

// ProgressReporter 进度报告接口
type ProgressReporter interface {
	UpdateProgress(progress *types.Progress) error
}

// Dispatcher 任务调度器
type Dispatcher struct {
	cfg      *config.Config
	reporter ProgressReporter

	// 统计计数
	total      int64
	processed  int64
	success    int64
	failed     int64
	startTime  time.Time
	lastReport time.Time

	// 错误收集
	errors     []types.ErrorInfo
	errorsLock sync.Mutex

	// 速率限制
	rateLimiter *RateLimiter
}

// NewDispatcher 创建调度器
func NewDispatcher(cfg *config.Config, rep ProgressReporter) *Dispatcher {
	d := &Dispatcher{
		cfg:      cfg,
		reporter: rep,
		errors:   make([]types.ErrorInfo, 0),
	}

	if cfg.Performance.RateLimit > 0 {
		d.rateLimiter = NewRateLimiter(cfg.Performance.RateLimit)
	}

	return d
}

// Run 运行调度器
func (d *Dispatcher) Run(ctx context.Context) (*types.Result, error) {
	d.startTime = time.Now()
	d.lastReport = d.startTime

	// 创建注入器
	inj, err := injector.New(d.cfg)
	if err != nil {
		return nil, fmt.Errorf("创建注入器失败: %w", err)
	}
	defer inj.Close()

	// 创建收件人读取器
	rdr, err := reader.New(d.cfg.Recipients.FilePath, d.cfg)
	if err != nil {
		return nil, fmt.Errorf("创建收件人读取器失败: %w", err)
	}
	defer rdr.Close()

	// 获取总数
	d.total, _ = rdr.Count()

	// 创建工作通道
	recipientCh := make(chan *reader.Recipient, d.cfg.Performance.ChannelBuffer)
	resultCh := make(chan *WorkResult, d.cfg.Performance.ChannelBuffer)
	doneCh := make(chan struct{})

	// 启动结果收集器
	go d.collectResults(ctx, resultCh, doneCh)

	// 启动进度报告器
	go d.reportProgress(ctx)

	// 【修复问题1】每个 worker 创建独立的 Builder（包含独立的 VariableProcessor 和 HeaderGenerator）
	// 这样每个 worker 拥有自己的随机数生成器、计数器等，完全避免并发竞争
	var wg sync.WaitGroup
	for i := 0; i < d.cfg.Performance.Workers; i++ {
		wg.Add(1)

		// 每个 worker 独立创建模板引擎和构建器
		tmplEngine, tmplErr := email.NewTemplateEngine(d.cfg.Email.TemplatePath)
		if tmplErr != nil {
			// 如果模板加载失败，减少 WaitGroup 并跳过此 worker
			wg.Done()
			return nil, fmt.Errorf("加载模板失败(worker %d): %w", i, tmplErr)
		}
		tmplEngine.SetGlobalVariables(d.cfg.Template.GlobalVariables)

		// 【v62修复】传入 workerID，确保每个 worker 的随机数种子唯一
		builder := email.NewBuilder(d.cfg, tmplEngine, i)

		go d.worker(ctx, i, recipientCh, resultCh, builder, inj, &wg)
	}

	// 【v63修复】worker 存活监控：当所有 worker 退出后（正常完成或全部崩溃），及时通知主线程
	// 防止所有 worker 崩溃后，主线程因往已满的 recipientCh 写入而永久阻塞（死锁）
	// Go 允许多个 goroutine 同时调用 wg.Wait()，所以这里和下方 line 160 的 wg.Wait() 不冲突
	workersDoneCh := make(chan struct{})
	go func() {
		wg.Wait()
		close(workersDoneCh)
	}()

	// 【修复问题10】读取收件人并分发：出错时记录日志并跳过，而非静默中断
	lineNum := 0
	skipLines := d.cfg.Recipients.SkipLines

readLoop:
	for {
		select {
		case <-ctx.Done():
			break readLoop
		default:
			recipient, err := rdr.Read()
			if err != nil {
				// 记录读取错误，但继续读取下一行
				d.errorsLock.Lock()
				if len(d.errors) < 1000 {
					d.errors = append(d.errors, types.ErrorInfo{
						Email: "",
						Error: fmt.Sprintf("读取收件人失败(行 %d): %v", lineNum+1, err),
						Line:  lineNum + 1,
					})
				}
				d.errorsLock.Unlock()
				atomic.AddInt64(&d.failed, 1)
				atomic.AddInt64(&d.processed, 1)
				continue // 跳过这一行，继续读取下一行
			}
			if recipient == nil {
				// 文件读取完毕
				break readLoop
			}

			lineNum++
			if lineNum <= skipLines {
				continue
			}

			recipient.LineNumber = lineNum

			select {
			case recipientCh <- recipient:
			case <-ctx.Done():
				break readLoop
			case <-workersDoneCh:
				// 【v63修复】所有 worker 已退出（可能全部崩溃），立即停止分发，避免死锁
				break readLoop
			}
		}
	}

	// 关闭收件人通道，等待工作完成
	close(recipientCh)
	wg.Wait()

	// 关闭结果通道，等待收集完成
	close(resultCh)
	<-doneCh

	// 构建结果
	result := d.buildResult(ctx)
	return result, nil
}

// WorkResult 工作结果
type WorkResult struct {
	Email   string
	Success bool
	Error   error
	Line    int
}

// worker 工作协程
// 【v64修复】recover 从 worker 级别改为 per-recipient 级别
// 之前：worker 遇到一次 panic 就整个退出，100个worker全死 → 只处理~1000封
// 现在：每封邮件单独 recover，即使 panic 也只跳过该封，worker 继续处理下一封
func (d *Dispatcher) worker(ctx context.Context, id int, recipientCh <-chan *reader.Recipient,
	resultCh chan<- *WorkResult, builder *email.Builder, inj *injector.Injector, wg *sync.WaitGroup) {
	defer wg.Done()
	// 保留 worker 级别 recover 作为最后防线（理论上不应再触发）
	defer func() {
		if r := recover(); r != nil {
			d.errorsLock.Lock()
			if len(d.errors) < 1000 {
				d.errors = append(d.errors, types.ErrorInfo{
					Email: "",
					Error: fmt.Sprintf("worker %d 发生意外崩溃(外层): %v", id, r),
					Line:  0,
				})
			}
			d.errorsLock.Unlock()
			atomic.AddInt64(&d.failed, 1)
			atomic.AddInt64(&d.processed, 1)
		}
	}()

	for {
		select {
		case <-ctx.Done():
			return
		case recipient, ok := <-recipientCh:
			if !ok {
				return
			}

			// 速率限制
			if d.rateLimiter != nil {
				d.rateLimiter.Wait(ctx)
			}

			// 【v64修复】每封邮件单独 recover，panic 不会杀死 worker
			result := d.safeProcessRecipient(ctx, id, recipient, builder, inj)

			select {
			case resultCh <- result:
			case <-ctx.Done():
				return
			}
		}
	}
}

// safeProcessRecipient 安全地处理单个收件人（per-recipient recover）
// 【v64修复】如果 processRecipient 内部发生 panic（如数组越界、nil指针等），
// 本方法会捕获 panic 并返回错误结果，worker 不受影响继续处理下一封
func (d *Dispatcher) safeProcessRecipient(ctx context.Context, workerID int,
	recipient *reader.Recipient, builder *email.Builder, inj *injector.Injector) (result *WorkResult) {

	defer func() {
		if r := recover(); r != nil {
			// 捕获 processRecipient 内部的 panic，返回错误结果
			result = &WorkResult{
				Email:   recipient.Email,
				Success: false,
				Error:   fmt.Errorf("worker %d 处理邮件时崩溃: %v", workerID, r),
				Line:    recipient.LineNumber,
			}
		}
	}()

	return d.processRecipient(ctx, recipient, builder, inj)
}

// processRecipient 处理单个收件人
func (d *Dispatcher) processRecipient(ctx context.Context, recipient *reader.Recipient,
	builder *email.Builder, inj *injector.Injector) *WorkResult {

	result := &WorkResult{
		Email: recipient.Email,
		Line:  recipient.LineNumber,
	}

	// 构建模板数据
	tmplData := email.NewTemplateData()
	tmplData.Email = recipient.Email
	tmplData.Name = recipient.Name
	tmplData.FirstName = recipient.FirstName
	tmplData.LastName = recipient.LastName
	tmplData.Data = recipient.CustomFields
	tmplData.System.Index = recipient.LineNumber
	tmplData.System.JobID = d.cfg.Job.ID

	// 生成邮件
	eml, err := builder.Build(tmplData)
	if err != nil {
		result.Error = fmt.Errorf("生成邮件失败: %w", err)
		return result
	}

	// 注入到 Pickup 目录
	if !d.cfg.DryRun {
		if err := inj.Inject(eml); err != nil {
			result.Error = fmt.Errorf("注入失败: %w", err)
			return result
		}
	}

	result.Success = true
	return result
}

// collectResults 收集结果
func (d *Dispatcher) collectResults(ctx context.Context, resultCh <-chan *WorkResult, doneCh chan<- struct{}) {
	defer close(doneCh)

	for {
		select {
		case result, ok := <-resultCh:
			if !ok {
				return
			}

			atomic.AddInt64(&d.processed, 1)

			if result.Success {
				atomic.AddInt64(&d.success, 1)
			} else {
				atomic.AddInt64(&d.failed, 1)

				// 记录错误
				d.errorsLock.Lock()
				if len(d.errors) < 1000 { // 最多记录1000个错误
					d.errors = append(d.errors, types.ErrorInfo{
						Email: result.Email,
						Error: result.Error.Error(),
						Line:  result.Line,
					})
				}
				d.errorsLock.Unlock()
			}

		case <-ctx.Done():
			// 继续处理完剩余的结果
			for result := range resultCh {
				atomic.AddInt64(&d.processed, 1)
				if result.Success {
					atomic.AddInt64(&d.success, 1)
				} else {
					atomic.AddInt64(&d.failed, 1)
				}
			}
			return
		}
	}
}

// reportProgress 进度报告
func (d *Dispatcher) reportProgress(ctx context.Context) {
	ticker := time.NewTicker(time.Duration(d.cfg.Performance.ProgressInterval) * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			d.updateProgress()
		}
	}
}

// updateProgress 更新进度
func (d *Dispatcher) updateProgress() {
	processed := atomic.LoadInt64(&d.processed)
	success := atomic.LoadInt64(&d.success)
	failed := atomic.LoadInt64(&d.failed)
	elapsed := time.Since(d.startTime).Seconds()

	var rate float64
	if elapsed > 0 {
		rate = float64(processed) / elapsed
	}

	var eta int64
	if rate > 0 && d.total > processed {
		eta = int64(float64(d.total-processed) / rate)
	}

	progress := &types.Progress{
		JobID:      d.cfg.Job.ID,
		Status:     "running",
		Total:      d.total,
		Processed:  processed,
		Success:    success,
		Failed:     failed,
		Rate:       rate,
		ETASeconds: eta,
		StartTime:  d.startTime,
		UpdateTime: time.Now(),
	}

	if d.reporter != nil {
		d.reporter.UpdateProgress(progress)
	}

	// 打印进度（防止除零）
	var percentage float64
	if d.total > 0 {
		percentage = float64(processed) / float64(d.total) * 100
	}
	fmt.Printf("\r[进度] %d/%d (%.1f%%) | 成功: %d | 失败: %d | 速率: %.0f/秒 | 剩余: %ds",
		processed, d.total, percentage,
		success, failed, rate, eta)
}

// buildResult 构建结果
func (d *Dispatcher) buildResult(ctx context.Context) *types.Result {
	endTime := time.Now()
	duration := endTime.Sub(d.startTime)

	processed := atomic.LoadInt64(&d.processed)
	success := atomic.LoadInt64(&d.success)
	failed := atomic.LoadInt64(&d.failed)

	var avgRate float64
	if duration.Seconds() > 0 {
		avgRate = float64(processed) / duration.Seconds()
	}

	status := "completed"
	if ctx.Err() != nil {
		status = "cancelled"
	}

	return &types.Result{
		JobID:       d.cfg.Job.ID,
		Status:      status,
		Total:       processed,
		Success:     success,
		Failed:      failed,
		StartTime:   d.startTime,
		EndTime:     endTime,
		Duration:    duration,
		AverageRate: avgRate,
		Errors:      d.errors,
	}
}
