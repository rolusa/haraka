package email

import (
	"math/rand"
	"strings"
	"unicode"
)

// 【Haraka26】零宽字符插入模块
// 在邮件主题、显示名、模板内容中随机插入零宽字符，
// 使每封邮件的文本指纹不同，防止反垃圾系统通过内容哈希批量拦截。

// 零宽字符集
var zeroWidthChars = []rune{
	'\u200B', // 零宽空格
	'\u200C', // 零宽非连接符
	'\u200D', // 零宽连接符
	'\uFEFF', // 零宽不换行空格
}

// 需要排除的标点/特殊字符（不在这些字符旁边插入零宽字符）
var excludeChars = map[rune]bool{
	'0': true, '1': true, '2': true, '3': true, '4': true,
	'5': true, '6': true, '7': true, '8': true, '9': true,
	'-': true, '，': true, '。': true, ',': true, '.': true,
	'：': true, ':': true, '/': true, '\\': true, '*': true,
	'?': true, '？': true, '!': true, '@': true, '#': true,
	'$': true, '%': true, '^': true, '&': true, '(': true,
	')': true, '=': true, '[': true, ']': true, '{': true,
	'}': true, '【': true, '】': true, '；': true, ';': true,
	'\'': true, '"': true, ''': true, '"': true, '《': true,
	'》': true, '<': true, '>': true, '+': true, '「': true,
	'」': true, '『': true, '』': true, '、': true, '・': true,
	'\r': true, '\n': true, '\t': true, ' ': true,
}

// InsertZeroWidth 在文本中随机插入零宽字符
// isHTML: 是否为 HTML 格式（如果是，只在文本节点内插入，不碰标签/属性）
func InsertZeroWidth(text string, isHTML bool) string {
	if text == "" {
		return text
	}

	lines := strings.Split(text, "\n")
	var result strings.Builder
	result.Grow(len(text) * 2)

	for lineIdx, line := range lines {
		if lineIdx > 0 {
			result.WriteByte('\n')
		}
		result.WriteString(insertZeroWidthInLine(line, isHTML))
	}

	return result.String()
}

// insertZeroWidthInLine 对单行文本插入零宽字符
func insertZeroWidthInLine(line string, isHTML bool) string {
	if len(line) == 0 {
		return line
	}

	runes := []rune(line)

	// 第 1 步：标记每个字符是否在"禁区"内
	// 禁区：{xxx} 变量、<xxx> HTML标签、&xxx; HTML实体
	inTag := false      // 在 HTML 标签 <...> 内
	inVariable := false // 在变量 {...} 内
	inEntity := false   // 在 HTML 实体 &...; 内
	safe := make([]bool, len(runes))

	for i, r := range runes {
		// 更新禁区状态
		switch {
		case r == '{':
			inVariable = true
		case r == '}':
			inVariable = false
			continue
		case r == '<' && isHTML:
			inTag = true
		case r == '>' && isHTML:
			inTag = false
			continue
		case r == '&' && isHTML:
			inEntity = true
		case r == ';' && isHTML && inEntity:
			inEntity = false
			continue
		}

		// 在禁区内 → 不安全
		if inTag || inVariable || inEntity {
			safe[i] = false
			continue
		}

		// 排除字符 → 不安全
		if excludeChars[r] {
			safe[i] = false
			continue
		}

		// 排除 ASCII 控制字符
		if r < 32 {
			safe[i] = false
			continue
		}

		// 必须是可见的文字字符（汉字、假名、字母等）
		if unicode.IsLetter(r) || unicode.Is(unicode.Han, r) || unicode.Is(unicode.Katakana, r) || unicode.Is(unicode.Hiragana, r) {
			safe[i] = true
		}
	}

	// 第 2 步：收集所有安全的插入位置（在安全字符之后插入）
	var safePositions []int
	for i := range runes {
		if safe[i] {
			safePositions = append(safePositions, i)
		}
	}

	if len(safePositions) == 0 {
		return line
	}

	// 第 3 步：随机选择 1-5 个位置插入零宽字符
	count := 1 + rand.Intn(5) // 1-5 个
	if count > len(safePositions) {
		count = len(safePositions)
	}

	// 随机打乱安全位置，取前 count 个
	shuffled := make([]int, len(safePositions))
	copy(shuffled, safePositions)
	rand.Shuffle(len(shuffled), func(i, j int) { shuffled[i], shuffled[j] = shuffled[j], shuffled[i] })
	insertPositions := make(map[int]bool)
	for i := 0; i < count; i++ {
		insertPositions[shuffled[i]] = true
	}

	// 第 4 步：构建结果字符串（在选中位置的字符之后插入零宽字符）
	var result strings.Builder
	result.Grow(len(line) + count*4)
	for i, r := range runes {
		result.WriteRune(r)
		if insertPositions[i] {
			// 随机选择一种零宽字符
			zw := zeroWidthChars[rand.Intn(len(zeroWidthChars))]
			result.WriteRune(zw)
		}
	}

	return result.String()
}
