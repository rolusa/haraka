package email

import (
	"math/rand"
	"strings"
	"unicode"
)

// 【Haraka26】零宽字符插入模块
// 在邮件主题、显示名、模板内容中随机插入零宽字符，
// 使每封邮件的文本指纹不同，防止反垃圾系统通过内容哈希批量拦截。

// 零宽字符集（4 种混用，增加指纹多样性）
var zeroWidthChars = []rune{
	'\u200B', // 零宽空格
	'\u200C', // 零宽非连接符
	'\u200D', // 零宽连接符
	'\uFEFF', // 零宽不换行空格
}

// 需要排除的标点/特殊字符
var excludeChars = map[rune]bool{
	'0': true, '1': true, '2': true, '3': true, '4': true,
	'5': true, '6': true, '7': true, '8': true, '9': true,
	'-': true, '，': true, '。': true, ',': true, '.': true,
	'：': true, ':': true, '/': true, '\\': true, '*': true,
	'?': true, '？': true, '!': true, '@': true, '#': true,
	'$': true, '%': true, '^': true, '&': true, '(': true,
	')': true, '=': true, '[': true, ']': true, '{': true,
	'}': true, '【': true, '】': true, '；': true, ';': true,
	'\'': true, '"': true, '\u2018': true, '\u201C': true, '\u300A': true,
	'\u300B': true, '<': true, '>': true, '+': true, '\u300C': true,
	'\u300D': true, '\u300E': true, '\u300F': true, '\u3001': true, '\u30FB': true,
	'\r': true, '\n': true, '\t': true, ' ': true, '_': true,
}

// InsertZeroWidth 在文本中随机插入零宽字符
// isHTML: 是否为 HTML 格式（仅影响 &xxx; 实体排除）
func InsertZeroWidth(text string, isHTML bool) string {
	if text == "" {
		return text
	}

	lines := strings.Split(text, "\n")
	var result strings.Builder
	result.Grow(len(text) * 2)

	for lineIdx, line := range lines {
		if lineIdx > 0 {
			result.WriteByte('\n')
		}
		result.WriteString(insertZeroWidthInLine(line, isHTML))
	}

	return result.String()
}

// insertZeroWidthInLine 对单行文本插入零宽字符
func insertZeroWidthInLine(line string, isHTML bool) string {
	if len(line) == 0 {
		return line
	}

	runes := []rune(line)
	n := len(runes)

	// 第 1 步：标记每个字符是否在"禁区"内
	// 禁区包括：
	//   - {xxx} 变量块（始终排除）
	//   - <xxx> HTML 标签（始终排除，防止破坏任何包含 HTML 的内容）
	//   - &xxx; HTML 实体（HTML 模式下排除）
	//   - http:// 或 https:// 开头的 URL（排除整个 URL 直到空白字符或 < 或 "）
	inTag := false      // 在 HTML 标签 <...> 内
	inVariable := false // 在变量 {...} 内
	inEntity := false   // 在 HTML 实体 &...; 内
	inURL := false      // 在 URL 内
	safe := make([]bool, n)

	for i, r := range runes {
		// URL 检测：http:// 或 https:// 开头 → 标记到空白字符或 < 或 " 为止
		if !inURL && !inTag && !inVariable {
			if r == 'h' && i+7 < n {
				rest := string(runes[i:])
				if strings.HasPrefix(rest, "http://") || strings.HasPrefix(rest, "https://") {
					inURL = true
				}
			}
		}

		// URL 结束检测：遇到空白、< 或 " 则结束
		if inURL {
			if r == ' ' || r == '\t' || r == '<' || r == '"' || r == '\'' || r == '>' || r == '\r' || r == '\n' {
				inURL = false
			} else {
				safe[i] = false
				continue
			}
		}

		// 更新禁区状态（<> 标签始终排除，不受 isHTML 限制）
		switch {
		case r == '{':
			inVariable = true
		case r == '}':
			inVariable = false
			safe[i] = false
			continue
		case r == '<':
			inTag = true
		case r == '>':
			inTag = false
			safe[i] = false
			continue
		case r == '&' && isHTML:
			inEntity = true
		case r == ';' && inEntity:
			inEntity = false
			safe[i] = false
			continue
		}

		// 在禁区内 → 不安全
		if inTag || inVariable || inEntity {
			safe[i] = false
			continue
		}

		// 排除字符 → 不安全
		if excludeChars[r] {
			safe[i] = false
			continue
		}

		// 排除 ASCII 控制字符
		if r < 32 {
			safe[i] = false
			continue
		}

		// 必须是可见的文字字符（汉字、假名、字母等）
		if unicode.IsLetter(r) || unicode.Is(unicode.Han, r) || unicode.Is(unicode.Katakana, r) || unicode.Is(unicode.Hiragana, r) {
			safe[i] = true
		}
	}

	// 第 2 步：收集所有安全的插入位置
	var safePositions []int
	for i := range runes {
		if safe[i] {
			safePositions = append(safePositions, i)
		}
	}

	if len(safePositions) == 0 {
		return line
	}

	// 第 3 步：随机选择 1-5 个位置插入零宽字符
	count := 1 + rand.Intn(5)
	if count > len(safePositions) {
		count = len(safePositions)
	}

	// 随机打乱安全位置，取前 count 个
	shuffled := make([]int, len(safePositions))
	copy(shuffled, safePositions)
	rand.Shuffle(len(shuffled), func(i, j int) { shuffled[i], shuffled[j] = shuffled[j], shuffled[i] })
	insertPositions := make(map[int]bool)
	for i := 0; i < count; i++ {
		insertPositions[shuffled[i]] = true
	}

	// 第 4 步：构建结果字符串
	var result strings.Builder
	result.Grow(len(line) + count*4)
	for i, r := range runes {
		result.WriteRune(r)
		if insertPositions[i] {
			zw := zeroWidthChars[rand.Intn(len(zeroWidthChars))]
			result.WriteRune(zw)
		}
	}

	return result.String()
}
