package email

import (
	"bytes"
	"fmt"
	htmltemplate "html/template"
	"os"
	"strings"
	texttemplate "text/template"
	"time"

	"__MODULE_PLACEHOLDER__/utils"
)

// TemplateData 模板数据
type TemplateData struct {
	// 收件人数据
	Email     string
	Name      string
	FirstName string
	LastName  string
	Data      map[string]string // 自定义字段

	// 全局变量
	Global map[string]interface{}

	// 系统变量
	System struct {
		Date      string
		DateTime  string
		Timestamp int64
		Year      int
		UUID      string
		JobID     string
		MessageID string
		Index     int
	}

	// 计算变量
	Computed struct {
		UnsubscribeURL string
		TrackingPixel  string
		Greeting       string
		EmailHash      string
	}
}

// NewTemplateData 创建模板数据
func NewTemplateData() *TemplateData {
	now := time.Now()
	return &TemplateData{
		Data:   make(map[string]string),
		Global: make(map[string]interface{}),
		System: struct {
			Date      string
			DateTime  string
			Timestamp int64
			Year      int
			UUID      string
			JobID     string
			MessageID string
			Index     int
		}{
			Date:      now.Format("2006-01-02"),
			DateTime:  now.Format("2006-01-02 15:04:05"),
			Timestamp: now.Unix(),
			Year:      now.Year(),
			UUID:      utils.GenerateUUID(),
		},
	}
}

// TemplateEngine 模板引擎
//
// 【Haraka28 修复】邮件头/主题渲染改用 text/template，避免 html/template 对
// <, >, &, ', " 等字符做 HTML 转义污染邮件头值（典型症状：
// Message-ID: <xxx@yyy>  →  Message-ID: &lt;xxx@yyy>）。
// 具体分工：
//   - HTML 正文（Render / RenderFile / RenderString）仍走 html/template，
//     保留自动 XSS 转义能力；
//   - 邮件头 / 主题（RenderStringText）走 text/template，不做任何转义，
//     真实还原用户输入。
type TemplateEngine struct {
	tmpl            *htmltemplate.Template
	rawContent      string
	globalVariables map[string]interface{}

	// 【修复问题7】字符串模板缓存：相同字符串只解析一次（html/template 版，用于 HTML 正文场景）
	stringCache map[string]*htmltemplate.Template

	// 【修复问题13】文件模板缓存：相同文件路径只读取+解析一次
	fileCache map[string]*htmltemplate.Template

	// 【Haraka28 新增】text/template 版字符串模板缓存，专供邮件头/主题渲染。
	// 与 stringCache 独立，避免两种模板类型互相污染。
	stringCacheText map[string]*texttemplate.Template
}

// NewTemplateEngine 创建模板引擎
func NewTemplateEngine(templatePath string) (*TemplateEngine, error) {
	content, err := os.ReadFile(templatePath)
	if err != nil {
		return nil, fmt.Errorf("读取模板文件失败: %w", err)
	}

	// 创建模板函数映射
	funcMap := createFuncMap()

	// 解析模板
	tmpl, err := htmltemplate.New("email").Funcs(funcMap).Parse(string(content))
	if err != nil {
		return nil, fmt.Errorf("解析模板失败: %w", err)
	}

	return &TemplateEngine{
		tmpl:            tmpl,
		rawContent:      string(content),
		globalVariables: make(map[string]interface{}),
		stringCache:     make(map[string]*htmltemplate.Template),
		fileCache:       make(map[string]*htmltemplate.Template),
		stringCacheText: make(map[string]*texttemplate.Template),
	}, nil
}

// SetGlobalVariables 设置全局变量
func (e *TemplateEngine) SetGlobalVariables(vars map[string]interface{}) {
	e.globalVariables = vars
}

// Render 渲染主模板（HTML 正文，走 html/template，含 XSS 自动转义）
func (e *TemplateEngine) Render(data *TemplateData) (string, error) {
	// 合并全局变量
	e.mergeGlobalVars(data)

	var buf bytes.Buffer
	if err := e.tmpl.Execute(&buf, data); err != nil {
		return "", fmt.Errorf("渲染模板失败: %w", err)
	}

	return buf.String(), nil
}

// RenderString 渲染字符串模板（html/template 版）
// 【修复问题7】使用缓存，相同字符串只 Parse 一次
//
// 注意：此方法会对输出做 HTML 上下文相关转义（<>&"' 可能被实体化）。
// 邮件头 / 主题场景请改用 RenderStringText，避免 &lt; 之类污染。
func (e *TemplateEngine) RenderString(text string, data *TemplateData) (string, error) {
	// 从缓存中查找
	tmpl, ok := e.stringCache[text]
	if !ok {
		// 首次遇到，解析并缓存
		funcMap := createFuncMap()
		var err error
		tmpl, err = htmltemplate.New("string").Funcs(funcMap).Parse(text)
		if err != nil {
			return text, err
		}
		e.stringCache[text] = tmpl
	}

	// 合并全局变量
	e.mergeGlobalVars(data)

	var buf bytes.Buffer
	if err := tmpl.Execute(&buf, data); err != nil {
		return text, err
	}

	return buf.String(), nil
}

// RenderStringText 渲染字符串模板（text/template 版，不做任何 HTML 转义）
//
// 【Haraka28 新增】专供邮件头 / 主题渲染。text/template 与 html/template 的
// 模板语法 100% 兼容（{{.Field}} / {{funcName arg}} / 管道 / 条件 / range 等），
// 差别只在输出转义：text/template 保证字面输出，字符如 <>&'" 一律原样保留。
//
// 语义与 RenderString 一致：
//   - 首次相同 text 会 Parse 并写入 stringCacheText 缓存；
//   - 解析失败：返回原始 text + error；
//   - 执行失败：返回原始 text + error；
//   - 成功：返回渲染结果 + nil。
//
// 上层调用点通常写作：`if rv, err := ...; err == nil { headerValue = rv }`，
// 出错时自动降级为 varProc 处理后的原值，保持鲁棒性。
func (e *TemplateEngine) RenderStringText(text string, data *TemplateData) (string, error) {
	// 空字符串直接返回，避免无谓的 Parse 缓存条目
	if text == "" {
		return text, nil
	}

	// 【Haraka28 快路径 & OOM 防护】
	// 若 text 不含 Go 模板 action 起始符 "{{"，直接返回原字符串。
	// 语义等价：text/template 对纯文本一定是 no-op，不做任何转义/替换。
	//
	// 这个快路径同时消除了一个重大内存风险：
	//   builder.go 里 varProc.Process 在本方法之前先跑，会把 {UUID}/{RANDOM:8}/{DATE_TIME}
	//   等 varProc 占位符替换成"每封邮件都不同"的具体值，然后把结果作为 text 传进来。
	//   若无脑走 Parse+stringCacheText[text]=tmpl，缓存 key 每封邮件都不同，
	//   跑 100 万封邮件就会有 100 万个 template 对象积累（每个 worker 独立缓存），
	//   在小内存 VPS 上直接 OOM。
	//
	// 加了这个快路径后：
	//   - 用户没在头值/主题写 {{...}} 语法（99% 场景）→ 完全不进缓存，零开销
	//   - 用户写了 {{.Field}} 但没在同一行混用 varProc 占位符 → 缓存 key = 用户静态配置行，条数固定
	//   - 用户混用 {UUID} 和 {{.Field}}（罕见）→ 仍会无界增长，但用户可自行避免
	if !strings.Contains(text, "{{") {
		return text, nil
	}

	// 从缓存中查找
	tmpl, ok := e.stringCacheText[text]
	if !ok {
		// 首次遇到，解析并缓存
		funcMap := createFuncMapText()
		var err error
		tmpl, err = texttemplate.New("string").Funcs(funcMap).Parse(text)
		if err != nil {
			return text, err
		}
		e.stringCacheText[text] = tmpl
	}

	// 合并全局变量
	e.mergeGlobalVars(data)

	var buf bytes.Buffer
	if err := tmpl.Execute(&buf, data); err != nil {
		return text, err
	}

	return buf.String(), nil
}

// RenderFile 渲染指定文件的模板（HTML 正文场景，走 html/template）
// 【修复问题13】使用缓存，相同文件只读取+解析一次
func (e *TemplateEngine) RenderFile(templatePath string, data *TemplateData) (string, error) {
	// 从缓存中查找
	tmpl, ok := e.fileCache[templatePath]
	if !ok {
		// 首次遇到，读取文件并解析
		content, err := os.ReadFile(templatePath)
		if err != nil {
			return "", fmt.Errorf("读取模板文件失败: %w", err)
		}

		funcMap := createFuncMap()
		tmpl, err = htmltemplate.New("file").Funcs(funcMap).Parse(string(content))
		if err != nil {
			return "", fmt.Errorf("解析模板失败: %w", err)
		}
		e.fileCache[templatePath] = tmpl
	}

	// 合并全局变量
	e.mergeGlobalVars(data)

	var buf bytes.Buffer
	if err := tmpl.Execute(&buf, data); err != nil {
		return "", fmt.Errorf("渲染模板失败: %w", err)
	}

	return buf.String(), nil
}

// mergeGlobalVars 合并全局变量到模板数据
func (e *TemplateEngine) mergeGlobalVars(data *TemplateData) {
	for k, v := range e.globalVariables {
		if data.Global == nil {
			data.Global = make(map[string]interface{})
		}
		data.Global[k] = v
	}
}

// commonFuncs 返回 html/template 与 text/template 共用的模板函数集合。
// 【Haraka28 重构】原 createFuncMap 里除 safeHTML/safeCSS/safeJS/safeURL 之外
// 的函数签名对两个引擎完全通用，抽出共用，避免复制粘贴漂移。
// 返回类型故意用 map[string]interface{}，方便两侧各自转换为对应 FuncMap 类型。
func commonFuncs() map[string]interface{} {
	return map[string]interface{}{
		// 字符串处理
		"upper":     strings.ToUpper,
		"lower":     strings.ToLower,
		"title":     strings.Title,
		"trim":      strings.TrimSpace,
		"replace":   strings.ReplaceAll,
		"contains":  strings.Contains,
		"hasPrefix": strings.HasPrefix,
		"hasSuffix": strings.HasSuffix,

		// 默认值
		"default": func(def, val interface{}) interface{} {
			if val == nil || val == "" {
				return def
			}
			return val
		},
		"or": func(vals ...interface{}) interface{} {
			for _, v := range vals {
				if v != nil && v != "" && v != 0 && v != false {
					return v
				}
			}
			return nil
		},

		// 截断
		"truncate": func(s string, length int) string {
			if len(s) <= length {
				return s
			}
			return s[:length]
		},

		// URL 编码
		"urlEncode": utils.URLEncode,
		"urlDecode": utils.URLDecode,

		// Base64 编码
		"base64Encode": utils.Base64Encode,
		"base64Decode": utils.Base64Decode,

		// 哈希
		"md5":    utils.MD5Hash,
		"sha256": utils.SHA256Hash,

		// 日期格式化
		"formatDate": func(t interface{}, layout string) string {
			switch v := t.(type) {
			case time.Time:
				return v.Format(layout)
			case string:
				if parsed, err := time.Parse(time.RFC3339, v); err == nil {
					return parsed.Format(layout)
				}
				return v
			default:
				return fmt.Sprintf("%v", t)
			}
		},
		"now": time.Now,

		// 数学运算
		"add": func(a, b int) int { return a + b },
		"sub": func(a, b int) int { return a - b },
		"mul": func(a, b int) int { return a * b },
		"div": func(a, b int) int {
			if b == 0 {
				return 0
			}
			return a / b
		},
		"mod": func(a, b int) int {
			if b == 0 {
				return 0
			}
			return a % b
		},

		// 条件
		"eq": func(a, b interface{}) bool { return a == b },
		"ne": func(a, b interface{}) bool { return a != b },
		"lt": func(a, b int) bool { return a < b },
		"le": func(a, b int) bool { return a <= b },
		"gt": func(a, b int) bool { return a > b },
		"ge": func(a, b int) bool { return a >= b },

		// 问候语
		"greeting": func() string {
			hour := time.Now().Hour()
			if hour < 12 {
				return "Good morning"
			} else if hour < 18 {
				return "Good afternoon"
			}
			return "Good evening"
		},

		// JSON
		"toJSON": utils.ToJSON,
	}
}

// createFuncMap 创建 html/template 模板函数映射（用于 HTML 正文渲染）
func createFuncMap() htmltemplate.FuncMap {
	m := commonFuncs()

	// HTML 安全类型：告诉 html/template 这些字符串已经安全，无需再转义
	m["safeHTML"] = func(s string) htmltemplate.HTML {
		return htmltemplate.HTML(s)
	}
	m["safeCSS"] = func(s string) htmltemplate.CSS {
		return htmltemplate.CSS(s)
	}
	m["safeJS"] = func(s string) htmltemplate.JS {
		return htmltemplate.JS(s)
	}
	m["safeURL"] = func(s string) htmltemplate.URL {
		return htmltemplate.URL(s)
	}

	return htmltemplate.FuncMap(m)
}

// createFuncMapText 创建 text/template 模板函数映射（用于邮件头/主题渲染）
//
// 【Haraka28 新增】text/template 本身不做任何转义，"safeXxx" 概念不存在；
// 但为避免用户在头值里手滑写了 {{safeHTML .Xxx}} 之类模板导致 Parse 失败/静默降级，
// 这里把它们降级为恒等函数（返回原字符串），语义完全等价（反正 text/template 不转义）。
func createFuncMapText() texttemplate.FuncMap {
	m := commonFuncs()

	// 恒等函数：text/template 不做转义，直接返回原字符串即可
	identity := func(s string) string { return s }
	m["safeHTML"] = identity
	m["safeCSS"] = identity
	m["safeJS"] = identity
	m["safeURL"] = identity

	return texttemplate.FuncMap(m)
}