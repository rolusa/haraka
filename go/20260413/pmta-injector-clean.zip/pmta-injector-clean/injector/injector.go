package injector

import (
	"fmt"
	"sync/atomic"
	"time"

	"__MODULE_PLACEHOLDER__/config"
	"__MODULE_PLACEHOLDER__/email"
	"__MODULE_PLACEHOLDER__/smtp"
)

// Injector 邮件注入器（通过 SMTP 发送到本地 MTA）
type Injector struct {
	cfg     *config.Config
	pool    *smtp.Pool
	counter uint64
	enabled bool
	addr    string
}

// New 创建注入器
func New(cfg *config.Config) (*Injector, error) {
	if !cfg.SMTP.Enabled {
		return &Injector{cfg: cfg, enabled: false}, nil
	}

	addr := fmt.Sprintf("%s:%d", cfg.SMTP.Host, cfg.SMTP.Port)

	poolSize := cfg.SMTP.MaxConn
	if poolSize <= 0 {
		poolSize = cfg.Performance.Workers
		if poolSize > 100 {
			poolSize = 100
		}
		if poolSize < 10 {
			poolSize = 10
		}
	}

	// 构建 AUTH 配置（Haraka 模式下需要认证，PowerMTA 本地免认证）
	var authCfg *smtp.AuthConfig
	if cfg.SMTP.UseAuth && cfg.SMTP.Username != "" {
		authCfg = &smtp.AuthConfig{
			UseAuth:  true,
			Username: cfg.SMTP.Username,
			Password: cfg.SMTP.Password,
		}
	}

	poolConfig := smtp.PoolConfig{
		Addr:           addr,
		Size:           poolSize,
		Timeout:        time.Duration(cfg.SMTP.Timeout) * time.Second,
		UseTLS:         cfg.SMTP.UseTLS,
		SkipVerify:     cfg.SMTP.SkipVerify,
		MaxSendPerConn: 100,
		Auth:           authCfg,
	}

	pool, err := smtp.NewPool(poolConfig)
	if err != nil {
		return nil, fmt.Errorf("创建 SMTP 连接池失败: %w", err)
	}

	return &Injector{cfg: cfg, pool: pool, enabled: true, addr: addr}, nil
}

// Inject 注入单封邮件
func (i *Injector) Inject(eml *email.Email) error {
	if !i.enabled {
		return fmt.Errorf("SMTP 发送未启用")
	}
	if i.pool == nil {
		return fmt.Errorf("SMTP 连接池未初始化")
	}

	err := i.pool.SendWithRetry(eml.EnvelopeFrom, eml.EnvelopeTo, []byte(eml.Raw), 2)
	if err != nil {
		return fmt.Errorf("SMTP 发送失败 [%s]: %w", eml.EnvelopeTo, err)
	}

	atomic.AddUint64(&i.counter, 1)
	return nil
}

// InjectBatch 批量注入
func (i *Injector) InjectBatch(emails []*email.Email) (int, error) {
	success := 0
	var lastErr error
	for _, eml := range emails {
		if err := i.Inject(eml); err != nil {
			lastErr = err
			continue
		}
		success++
	}
	if lastErr != nil && success < len(emails) {
		return success, fmt.Errorf("部分邮件发送失败 (%d/%d): %w", success, len(emails), lastErr)
	}
	return success, nil
}

func (i *Injector) GetCounter() uint64    { return atomic.LoadUint64(&i.counter) }
func (i *Injector) GetSMTPAddr() string   { return i.addr }
func (i *Injector) IsEnabled() bool       { return i.enabled }

func (i *Injector) GetStats() *smtp.PoolStats {
	if i.pool == nil {
		return nil
	}
	stats := i.pool.Stats()
	return &stats
}

func (i *Injector) Close() {
	if i.pool != nil {
		i.pool.Close()
	}
}
