package email

// 【v66新增】字符编码转换模块
// 支持将 Go 内部的 UTF-8 字符串/字节转换为目标编码（Shift_JIS、ISO-2022-JP、EUC-JP、GB2312、GBK）
// 用于邮件 Subject、正文、显示名的编码，确保 Content-Type charset 标签和实际内容一致

import (
	"strings"

	"golang.org/x/text/encoding"
	"golang.org/x/text/encoding/japanese"
	"golang.org/x/text/encoding/simplifiedchinese"
	"golang.org/x/text/transform"
)

// getEncoder 根据 charset 名称获取对应的编码器
// 返回 nil 表示 UTF-8 或不支持的编码（不做转换）
func getEncoder(charset string) *encoding.Encoder {
	switch strings.ToLower(strings.TrimSpace(charset)) {
	case "shift_jis", "shift-jis", "sjis", "windows-31j", "cp932":
		return japanese.ShiftJIS.NewEncoder()
	case "iso-2022-jp", "iso2022jp":
		return japanese.ISO2022JP.NewEncoder()
	case "euc-jp", "eucjp":
		return japanese.EUCJP.NewEncoder()
	case "gb2312", "gbk", "gb18030", "cp936", "windows-936":
		return simplifiedchinese.GBK.NewEncoder()
	case "hz-gb-2312", "hz-gb2312":
		return simplifiedchinese.HZGB2312.NewEncoder()
	default:
		// UTF-8、US-ASCII 或未知编码 → 不做转换
		return nil
	}
}

// isUTF8Charset 判断 charset 是否为 UTF-8（不需要转换）
func isUTF8Charset(charset string) bool {
	lower := strings.ToLower(strings.TrimSpace(charset))
	return lower == "" || lower == "utf-8" || lower == "utf8" || lower == "us-ascii" || lower == "ascii"
}

// ConvertFromUTF8 将 UTF-8 字节转换为目标编码的字节
// 如果 charset 是 UTF-8 或不支持的编码，直接返回原始字节（不做转换）
// 如果转换失败（例如目标编码不支持某些字符），返回原始 UTF-8 字节
func ConvertFromUTF8(utf8Bytes []byte, charset string) []byte {
	if isUTF8Charset(charset) {
		return utf8Bytes
	}

	encoder := getEncoder(charset)
	if encoder == nil {
		return utf8Bytes
	}

	// 使用 transform 进行编码转换
	result, _, err := transform.Bytes(encoder, utf8Bytes)
	if err != nil {
		// 转换失败（例如字符不在目标编码范围内），返回原始 UTF-8 字节
		return utf8Bytes
	}

	return result
}

// ConvertStringFromUTF8 将 UTF-8 字符串转换为目标编码的字节
func ConvertStringFromUTF8(s string, charset string) []byte {
	return ConvertFromUTF8([]byte(s), charset)
}
