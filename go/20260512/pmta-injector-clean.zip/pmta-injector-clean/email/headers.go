package email

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"math/big"
	mathrand "math/rand"
	"strings"
	"time"

	"__MODULE_PLACEHOLDER__/config"
)

// ========================================================================
// 【方案 B】伪 DKIM-Signature 的外部域签名池
// 设计思路：
//   伪签名故意将 d= 设为外部大厂域名（而非发件方真实域名），让接收方反垃圾系统
//   将"DKIM 校验失败"归因于"邮件经过外部中转链路时签名损坏"——这是邮件世界
//   常态（邮件列表/转发/反垃圾扫描都会破坏原始签名），反垃圾系统对此宽容。
//   而非"发件方自家签名都对不上"——后者被视为伪造，扣分严重。
//
// 域名 + selector 选取策略：
//   - 静态 selector 池：覆盖真实大厂当前/历史 selector 风格
//     （gmail 日期格式 / outlook selector1/2 / yahoo s2048 / icloud 1a1hai 等）
//   - SES 风格：每次动态生成 32 字符 base32 随机串（amazonses.com 每客户独立）
//   - 加权抽样：模拟真实邮件流量比例（gmail/outlook 高频，企业 SaaS 低频）
//   - 反指纹环形缓冲区：每个 worker 内记忆最近 8 次用过的源索引，避免短期重复
// ========================================================================

// dkimExternalSource 一个伪签名候选源（外部大厂域 + 该域的合理 selector 池 + 抽样权重）
type dkimExternalSource struct {
	domain    string   // d= 字段使用的外部域名
	selectors []string // 候选 selector（每封邮件从中随机一个）；isSESLike=true 时忽略
	weight    int      // 加权抽样权重（值越高被抽中概率越大，模拟真实流量分布）
	isSESLike bool     // true 时 selector 每次动态生成 32 字符 base32 随机串
}

// dkimExternalSources 外部大厂域签名池（约 50 个组合，按真实邮件流量加权）
// 权重总和约 130，单源最大 20（gmail.com ~15%），最小 1（长尾企业域）
var dkimExternalSources = []dkimExternalSource{
	// ===== Google 系（~25%）=====
	{"gmail.com", []string{"20230601", "20221208", "20210112", "20161025"}, 20, false},
	{"googlemail.com", []string{"20230601", "20221208"}, 4, false},
	{"google.com", []string{"20221208", "20230601"}, 4, false},

	// ===== Microsoft 系（~20%）=====
	{"outlook.com", []string{"selector1", "selector2"}, 12, false},
	{"hotmail.com", []string{"selector1", "selector2"}, 7, false},
	{"live.com", []string{"selector1", "selector2"}, 4, false},
	{"microsoft.com", []string{"selector1", "selector2"}, 3, false},
	{"office365.com", []string{"selector1"}, 2, false},

	// ===== Yahoo 系（~10%，含日本 Yahoo 针对 docomo 场景加分）=====
	{"yahoo.com", []string{"s2048", "s1024", "s1"}, 6, false},
	{"yahoo.co.jp", []string{"s2048", "s1024"}, 6, false},
	{"ymail.com", []string{"s2048"}, 2, false},

	// ===== Apple 系（~5%）=====
	{"icloud.com", []string{"1a1hai", "sig1"}, 5, false},
	{"me.com", []string{"1a1hai"}, 2, false},

	// ===== Amazon SES（~10%，selector 每次动态 32 字符随机生成）=====
	{"amazonses.com", nil, 10, true},

	// ===== ESP 邮件服务商（~15%）=====
	{"sendgrid.net", []string{"s1", "smtpapi", "m1"}, 5, false},
	{"sendgrid.me", []string{"s1"}, 1, false},
	{"mailgun.org", []string{"k1", "mg", "pic"}, 4, false},
	{"mandrillapp.com", []string{"mandrill", "mte1"}, 3, false},
	{"mcsv.net", []string{"k2"}, 2, false},
	{"mtasv.net", []string{"20150623"}, 1, false},
	{"sparkpostmail.com", []string{"scph1220"}, 1, false},
	{"hubspotemail.net", []string{"hs1"}, 2, false},

	// ===== 日本本地邮件商（~10%，docomo 场景加分）=====
	{"nifty.com", []string{"default"}, 2, false},
	{"biglobe.ne.jp", []string{"default"}, 2, false},
	{"so-net.ne.jp", []string{"s1024"}, 2, false},
	{"ocn.ad.jp", []string{"default"}, 1, false},
	{"plala.or.jp", []string{"default"}, 1, false},

	// ===== 企业 SaaS / 营销邮件（~5%，长尾多样性）=====
	{"salesforce.com", []string{"200608"}, 1, false},
	{"pardot.com", []string{"pardotdkim"}, 1, false},
	{"linkedin.com", []string{"proddkim1024"}, 1, false},
	{"paypal.com", []string{"pp-dkim1"}, 1, false},
	{"adobe.com", []string{"s2048"}, 1, false},
	{"zoho.com", []string{"zmail"}, 1, false},
	{"zendesk.com", []string{"mail"}, 1, false},
	{"intercom-mail.com", []string{"intercom"}, 1, false},
	{"protonmail.com", []string{"protonmail"}, 1, false},
	{"fastmail.com", []string{"fm1"}, 1, false},
}

// 反指纹环形缓冲区容量（每个 HeaderGenerator/worker 独立维护）
// 8 = 同一 worker 最近 8 次抽样不重复；50 个池子下避免重复几乎不会失败
const dkimRecentRingSize = 8

// Amazon SES 风格 selector 的字符集（base32 小写字母 + 数字 2-7，共 32 字符）
const dkimSESCharset = "abcdefghijklmnopqrstuvwxyz234567"

// HeaderGenerator 邮件头生成器
// 【修复问题2】每个实例拥有独立的随机数生成器，避免全局rand争锁
// 【方案 B 新增】dkimRecent 环形缓冲区用于伪 DKIM 选源的反指纹去重
type HeaderGenerator struct {
	cfg    *config.HeadersConfig
	random *mathrand.Rand

	// 【方案 B】伪 DKIM 反指纹：记录最近用过的 dkimExternalSources 索引，
	// 抽样时排除最近 N 次结果，避免短时间内同一 worker 反复使用相同 d+s 组合
	// （否则反垃圾系统能从"该 IP 多封邮件都声称经过同一外部服务中转"识别出指纹）
	dkimRecent    []int // 环形缓冲区（容量 = dkimRecentRingSize）
	dkimRecentPos int   // 下一次写入的位置
}

// NewHeaderGenerator 创建邮件头生成器
// 【v62修复】使用 crypto/rand 生成安全种子 + workerID 偏移，彻底避免并发种子碰撞
// 【方案 B 新增】初始化伪 DKIM 反指纹环形缓冲区
func NewHeaderGenerator(cfg *config.HeadersConfig, workerID int) *HeaderGenerator {
	// 全部填 -1 表示"空槽" —— 不能填 0，因为 0 是 dkimExternalSources 的有效索引,
	// 否则第一次抽样会把 idx=0 误判为"最近用过"，导致选源逻辑首轮异常
	recent := make([]int, dkimRecentRingSize)
	for i := range recent {
		recent[i] = -1
	}
	return &HeaderGenerator{
		cfg:           cfg,
		random:        mathrand.New(mathrand.NewSource(cryptoSeed(workerID))),
		dkimRecent:    recent,
		dkimRecentPos: 0,
	}
}

// GenerateHeaders 生成启用的自定义邮件头（不含Received和DKIM，它们在builder中单独处理）
// fromAddress: 发件人地址, toAddress: 收件人地址, domain: 发件域名
func (hg *HeaderGenerator) GenerateHeaders(fromAddress, toAddress, domain string) string {
	if hg.cfg == nil || !hg.cfg.Enabled {
		return ""
	}

	var sb strings.Builder

	// 注意: Received 和 DKIM-Signature 在 builder.go 的 buildRawEmail 中单独处理
	// 注意: Message-ID 在 builder.go 的 buildRawEmail 中单独处理

	// Reply-To
	if hg.cfg.ReplyTo {
		sb.WriteString(fmt.Sprintf("Reply-To: %s\r\n", hg.getReplyToAddress(fromAddress, domain)))
	}

	// Return-Path
	if hg.cfg.ReturnPath {
		sb.WriteString(fmt.Sprintf("Return-Path: <%s>\r\n", hg.getReturnPathAddress(fromAddress, domain)))
	}

	// X-Mailer
	if hg.cfg.XMailer {
		sb.WriteString(fmt.Sprintf("X-Mailer: %s\r\n", hg.getRandomXMailer()))
	}

	// X-Priority
	if hg.cfg.XPriority {
		sb.WriteString(fmt.Sprintf("X-Priority: %s\r\n", hg.getXPriorityValue()))
	}

	// Importance
	if hg.cfg.Importance {
		sb.WriteString(fmt.Sprintf("Importance: %s\r\n", hg.getImportanceValue()))
	}

	// Accept-Language
	if hg.cfg.AcceptLanguage {
		sb.WriteString(fmt.Sprintf("Accept-Language: %s\r\n", hg.getAcceptLanguageValue()))
	}

	// Content-Language
	if hg.cfg.ContentLanguage {
		sb.WriteString(fmt.Sprintf("Content-Language: %s\r\n", hg.getContentLanguageValue()))
	}

	// 注意：用户自定义邮件头（CustomHeadersText）已移到 builder.go 的 buildRawEmail 中处理，
	// 因为 builder 那里有完整的 recipient 和 data 上下文，可以正确做变量替换和模板渲染。
	// 不要在这里处理！

	return sb.String()
}

// ===== Received 头生成 =====

func (hg *HeaderGenerator) generateReceived(fromAddress, toAddress, domain string) string {
	randomDomain := hg.generateRandomDomain()
	randomIP := hg.generateRandomIPRealistic()
	mailID := hg.generateMailID()
	username := hg.generateRandomUsername()
	tlsVersion := hg.randomChoice([]string{"TLS1_2,", "TLS1_3,"})
	cipher := hg.randomChoice(tlsCiphers)
	serverSoftware := hg.randomChoice(mailServerSoftware)
	now := time.Now().Format("Mon, 02 Jan 2006 15:04:05 -0700")

	received := fmt.Sprintf("Received: from %s ([%s])\r\n"+
		" (Authenticated sender: %s@%s)\r\n"+
		" by %s (%s) with ESMTPSA id %s\r\n"+
		" for <%s>;\r\n"+
		" %s %s %s\r\n",
		randomDomain, randomIP,
		username, domain,
		domain, serverSoftware, mailID,
		toAddress,
		tlsVersion, cipher, now)

	return received
}

// ===== DKIM-Signature 头生成 =====

// generateDkimSignature 生成伪 DKIM-Signature 头（【方案 B】外部域伪转发签名）
// 设计要点见文件顶部 dkimExternalSources 的注释块。
//
// 参数 fromAddress / domain 保留以维持函数签名与调用方兼容，但本实现故意不使用 ——
// 伪签名的 d= 指向外部大厂域而非发件方真实域名，将校验失败归因于"中转链路签名损坏"
// （邮件常态、反垃圾宽容），而非"发件方自家签名都对不上"（被视为伪造、严重扣分）。
func (hg *HeaderGenerator) generateDkimSignature(fromAddress, domain string) string {
	_ = fromAddress // 故意不使用，理由见上方注释
	_ = domain

	src := hg.pickDkimExternalSource()

	// selector：SES 风格的每次动态生成 32 字符 base32 串，其余从该源的候选池里随机选
	var selector string
	if src.isSESLike {
		selector = hg.generateSESLikeSelector()
	} else if len(src.selectors) > 0 {
		selector = src.selectors[safeIntn(hg.random, len(src.selectors))]
	} else {
		// 兜底：数据池不一致时落到该分支（正常配置不会到达）
		selector = "default"
	}

	bh := generateRandomBase64(32)
	sig := generateRandomBase64Multiline(256)
	timestamp := time.Now().Unix()

	return fmt.Sprintf("DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;\r\n"+
		" d=%s; s=%s; t=%d;\r\n"+
		" h=From:To:Subject:Date:Message-ID:MIME-Version:Content-Type:Content-Transfer-Encoding;\r\n"+
		" bh=%s;\r\n"+
		" b=%s\r\n",
		src.domain, selector, timestamp,
		bh,
		sig)
}

// pickDkimExternalSource 按权重加权抽样 dkimExternalSources，并尽量避开 worker 最近用过的源
//
// 实现要点：
//  1. 累计 totalWeight 后用一次 safeIntn 实现加权抽样（O(n) 扫描）
//  2. 最多重试 dkimRecentRingSize+2 次以躲开最近历史；超过仍未找到就接受重复
//     （50 个源、最近 8 个，理论上必然能找到非重复项；上限是兜底防极端 case）
func (hg *HeaderGenerator) pickDkimExternalSource() *dkimExternalSource {
	// 兜底：数据池为空（理论不可能）
	if len(dkimExternalSources) == 0 {
		return &dkimExternalSource{domain: "gmail.com", selectors: []string{"20230601"}}
	}

	totalWeight := 0
	for i := range dkimExternalSources {
		totalWeight += dkimExternalSources[i].weight
	}
	// 兜底：所有权重均 ≤ 0（理论不可能），退化为首项
	if totalWeight <= 0 {
		return &dkimExternalSources[0]
	}

	maxRetry := dkimRecentRingSize + 2
	lastIdx := 0
	for retry := 0; retry < maxRetry; retry++ {
		r := safeIntn(hg.random, totalWeight)
		idx := 0
		for i := range dkimExternalSources {
			r -= dkimExternalSources[i].weight
			if r < 0 {
				idx = i
				break
			}
		}
		lastIdx = idx
		if !hg.isDkimSourceRecent(idx) {
			hg.recordDkimSource(idx)
			return &dkimExternalSources[idx]
		}
	}

	// 重试用完仍未避开最近历史 —— 接受重复（极端情况下池子过小或权重过偏）
	hg.recordDkimSource(lastIdx)
	return &dkimExternalSources[lastIdx]
}

// isDkimSourceRecent 检查源索引 idx 是否在最近用过的环形缓冲区中
func (hg *HeaderGenerator) isDkimSourceRecent(idx int) bool {
	for _, v := range hg.dkimRecent {
		if v == idx {
			return true
		}
	}
	return false
}

// recordDkimSource 把刚使用的源索引写入环形缓冲区（覆盖最旧的一条）
func (hg *HeaderGenerator) recordDkimSource(idx int) {
	hg.dkimRecent[hg.dkimRecentPos] = idx
	hg.dkimRecentPos = (hg.dkimRecentPos + 1) % dkimRecentRingSize
}

// generateSESLikeSelector 生成 Amazon SES 风格的 32 字符 base32 随机 selector
// 真实 SES 中每个客户独立分配此类 selector，因此动态生成不会暴露指纹
func (hg *HeaderGenerator) generateSESLikeSelector() string {
	b := make([]byte, 32)
	for i := range b {
		b[i] = dkimSESCharset[safeIntn(hg.random, len(dkimSESCharset))]
	}
	return string(b)
}

// ===== Message-ID 生成（模拟不同客户端风格）=====

// GenerateCustomMessageID 生成模拟不同客户端风格的 Message-ID
// 【修复问题2】改为实例方法，使用独立随机源
func (hg *HeaderGenerator) GenerateCustomMessageID(domain string) string {
	// 提取域名
	if idx := strings.Index(domain, "@"); idx != -1 {
		domain = domain[idx+1:]
	}

	styles := []func(string) string{
		// Outlook 风格: <GUID@domain>
		func(d string) string {
			return fmt.Sprintf("%s@%s", strings.ToUpper(generateGUID()), d)
		},
		// Thunderbird 风格: <random-hex@domain>
		func(d string) string {
			b := make([]byte, 16)
			rand.Read(b)
			return fmt.Sprintf("%s@%s", hex.EncodeToString(b), d)
		},
		// Gmail 风格: <CAGB+random@mail.gmail.com-like>
		func(d string) string {
			b := make([]byte, 21)
			rand.Read(b)
			encoded := base64.RawURLEncoding.EncodeToString(b)
			return fmt.Sprintf("CAGB%s@%s", encoded[:28], d)
		},
		// Apple Mail 风格: <UUID@domain>
		func(d string) string {
			return fmt.Sprintf("%s@%s", generateGUID(), d)
		},
		// 时间戳风格: <timestamp.random@domain>
		func(d string) string {
			ts := time.Now().UnixNano()
			b := make([]byte, 6)
			rand.Read(b)
			return fmt.Sprintf("%d.%s@%s", ts, hex.EncodeToString(b), d)
		},
		// 短随机风格: <random12@domain>
		func(d string) string {
			b := make([]byte, 8)
			rand.Read(b)
			return fmt.Sprintf("%s@%s", hex.EncodeToString(b), d)
		},
	}

	style := styles[safeIntn(hg.random, len(styles))]
	return style(domain)
}

// ===== X-Priority =====

func (hg *HeaderGenerator) getXPriorityValue() string {
	val := hg.cfg.XPriorityValue
	switch val {
	case "1 (Highest)":
		return "1"
	case "2 (High)":
		return "2"
	case "3 (Normal)":
		return "3"
	default: // 随机选择
		choices := []string{"1", "2", "3"}
		return hg.randomChoice(choices)
	}
}

// ===== Importance =====

func (hg *HeaderGenerator) getImportanceValue() string {
	val := hg.cfg.ImportanceValue
	switch val {
	case "high", "normal", "low":
		return val
	default: // 随机选择
		choices := []string{"high", "normal", "low"}
		return hg.randomChoice(choices)
	}
}

// ===== Reply-To =====

func (hg *HeaderGenerator) getReplyToAddress(fromAddress, domain string) string {
	switch hg.cfg.ReplyToMode {
	case "random_prefix":
		return hg.generateRandomEmailPrefix() + "@" + domain
	default: // from_address
		return fromAddress
	}
}

// ===== Return-Path =====

func (hg *HeaderGenerator) getReturnPathAddress(fromAddress, domain string) string {
	switch hg.cfg.ReturnPathMode {
	case "random_prefix":
		return hg.generateRandomEmailPrefix() + "@" + domain
	default: // from_address
		return fromAddress
	}
}

// ===== Accept-Language =====

func (hg *HeaderGenerator) getAcceptLanguageValue() string {
	val := hg.cfg.AcceptLangValue
	switch val {
	case "ja", "en", "ja-JP", "en-US", "zh-CN":
		return val
	default: // 随机选择
		choices := []string{"ja", "en", "ja-JP", "en-US", "zh-CN"}
		return hg.randomChoice(choices)
	}
}

// ===== Content-Language =====

func (hg *HeaderGenerator) getContentLanguageValue() string {
	val := hg.cfg.ContentLangValue
	switch val {
	case "ja", "en", "ja-JP", "en-US", "zh-CN":
		return val
	default: // 随机选择
		choices := []string{"ja", "en", "ja-JP", "en-US", "zh-CN"}
		return hg.randomChoice(choices)
	}
}

// ===== 辅助函数 =====

// randomChoice 从切片中随机选择一个元素
// 【修复问题2】使用实例级别随机源替代全局rand
// 【v62修复】使用 safeIntn 确保索引永远不越界
func (hg *HeaderGenerator) randomChoice(choices []string) string {
	if len(choices) == 0 {
		return ""
	}
	return choices[safeIntn(hg.random, len(choices))]
}

// generateRandomDomain 生成随机域名
func (hg *HeaderGenerator) generateRandomDomain() string {
	formats := []func() string{
		// 格式1: mail.random.tld
		func() string {
			suffix := randomHexString(7)
			tld := hg.randomChoice(domainTLDs)
			return fmt.Sprintf("mail.%s.%s", suffix, tld)
		},
		// 格式2: smtp.word-suffix.tld
		func() string {
			word := hg.randomChoice(domainWords)
			suffix := hg.randomChoice(domainSuffixes)
			tld := hg.randomChoice(domainTLDs)
			return fmt.Sprintf("smtp.%s-%s.%s", word, suffix, tld)
		},
	}
	return formats[safeIntn(hg.random, len(formats))]()
}

// generateRandomIPRealistic 生成真实范围的随机IP
func (hg *HeaderGenerator) generateRandomIPRealistic() string {
	validRanges := [][2]int{
		{1, 9}, {11, 126}, {128, 169}, {171, 171},
		{173, 191}, {193, 223},
	}
	r := validRanges[safeIntn(hg.random, len(validRanges))]
	first := safeIntn(hg.random, r[1]-r[0]+1) + r[0]
	second := safeIntn(hg.random, 255)
	third := safeIntn(hg.random, 255)
	fourth := safeIntn(hg.random, 254) + 1
	return fmt.Sprintf("%d.%d.%d.%d", first, second, third, fourth)
}

// generateMailID 生成随机邮件传输ID
func (hg *HeaderGenerator) generateMailID() string {
	const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, 8)
	for i := range result {
		n, _ := rand.Int(rand.Reader, big.NewInt(int64(len(chars))))
		result[i] = chars[n.Int64()]
	}
	dash1 := randomHexString(4)
	dash2 := randomHexString(4)
	dash3 := randomHexString(4)
	return fmt.Sprintf("%s-%s-%s-%s.%d", strings.ToUpper(string(result)), strings.ToUpper(dash1), strings.ToUpper(dash2), strings.ToUpper(dash3), safeIntn(hg.random, 9)+1)
}

// generateRandomUsername 生成随机用户名
func (hg *HeaderGenerator) generateRandomUsername() string {
	usernames := []string{
		"username", "user", "mail", "admin", "sender", "client",
		"account", "mailer", "webmaster", "system", "daemon",
		"notification", "postmaster", "mailsystem", "automated", "monitor",
	}
	name := hg.randomChoice(usernames)
	number := safeIntn(hg.random, 1000)
	return fmt.Sprintf("%s%03d", name, number)
}

// generateRandomEmailPrefix 生成随机邮箱前缀
func (hg *HeaderGenerator) generateRandomEmailPrefix() string {
	prefixes := []string{
		"noreply", "no-reply", "info", "support", "admin", "contact",
		"service", "notification", "alert", "mail", "system", "notice",
		"account", "security", "verify", "update", "billing", "help",
	}
	prefix := hg.randomChoice(prefixes)
	if safeIntn(hg.random, 3) == 0 {
		// 30%概率添加数字后缀
		prefix = fmt.Sprintf("%s%d", prefix, safeIntn(hg.random, 100))
	}
	return prefix
}

// generateGUID 生成GUID格式字符串
func generateGUID() string {
	b := make([]byte, 16)
	rand.Read(b)
	return fmt.Sprintf("%08X-%04X-%04X-%04X-%012X",
		b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}

// generateRandomBase64 生成指定字节数的随机Base64字符串
func generateRandomBase64(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return base64.StdEncoding.EncodeToString(b)
}

// generateRandomBase64Multiline 生成多行随机Base64（模拟DKIM签名）
func generateRandomBase64Multiline(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	encoded := base64.StdEncoding.EncodeToString(b)
	var lines []string
	lineLen := 72
	for i := 0; i < len(encoded); i += lineLen {
		end := i + lineLen
		if end > len(encoded) {
			end = len(encoded)
		}
		lines = append(lines, encoded[i:end])
	}
	return strings.Join(lines, "\r\n   ")
}

// randomHexString 生成随机十六进制字符串
func randomHexString(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)[:n]
}

// ===== TLS加密套件列表 =====

var tlsCiphers = []string{
	"cipher=TLS_RSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);",
	"cipher=TLS_RSA_WITH_AES_256_GCM_SHA384 (authenticated bits=0);",
	"cipher=TLS_RSA_WITH_AES_128_CBC_SHA (authenticated bits=0);",
	"cipher=TLS_RSA_WITH_AES_256_CBC_SHA (authenticated bits=0);",
	"cipher=TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);",
	"cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 (authenticated bits=0);",
	"cipher=TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA (authenticated bits=0);",
	"cipher=TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA (authenticated bits=0);",
	"cipher=TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);",
	"cipher=TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 (authenticated bits=0);",
	"cipher=TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 (authenticated bits=0);",
	"cipher=TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 (authenticated bits=0);",
	"cipher=TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 (authenticated bits=0);",
	"cipher=TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 (authenticated bits=0);",
	"cipher=TLS_AES_128_GCM_SHA256 (authenticated bits=0);",
	"cipher=TLS_AES_256_GCM_SHA384 (authenticated bits=0);",
	"cipher=TLS_CHACHA20_POLY1305_SHA256 (authenticated bits=0);",
}

// ===== 域名生成用数据 =====

var domainTLDs = []string{
	"com", "net", "org", "jp", "ne.jp", "co.jp", "or.jp", "ac.jp", "ad.jp", "ed.jp",
	"go.jp", "gr.jp", "lg.jp", "edu", "gov", "app", "blog", "shop", "online", "site",
	"store", "tech", "cloud", "email", "news", "media", "agency", "company", "business",
	"services", "aichi.jp", "akita.jp", "aomori.jp", "chiba.jp", "ehime.jp", "fukui.jp",
	"fukuoka.jp", "fukushima.jp", "gifu.jp", "gunma.jp", "hiroshima.jp", "hokkaido.jp",
	"hyogo.jp", "ibaraki.jp", "ishikawa.jp", "iwate.jp", "kagawa.jp", "kagoshima.jp",
	"kanagawa.jp", "kochi.jp", "kumamoto.jp", "kyoto.jp", "mie.jp", "miyagi.jp",
	"miyazaki.jp", "nagano.jp", "nagasaki.jp", "nara.jp", "niigata.jp", "oita.jp",
	"okayama.jp", "okinawa.jp", "osaka.jp", "saga.jp", "saitama.jp", "shiga.jp",
	"shimane.jp", "shizuoka.jp", "tochigi.jp", "tokushima.jp", "tokyo.jp", "tottori.jp",
	"toyama.jp", "wakayama.jp", "yamagata.jp", "yamaguchi.jp", "yamanashi.jp",
	"yokohama.jp", "kawasaki.jp", "sapporo.jp", "sendai.jp",
	"pref.aichi.jp", "pref.osaka.jp", "pref.kanagawa.jp", "pref.saitama.jp",
	"pref.chiba.jp", "pref.fukuoka.jp", "pref.hiroshima.jp", "pref.hokkaido.jp",
	"pref.hyogo.jp", "pref.kyoto.jp",
	"waseda.jp", "keio.jp", "u-tokyo.jp", "kyoto-u.jp", "osaka-u.jp",
	"ntt.jp", "softbank.jp", "kddi.jp", "docomo.jp", "rakuten.jp",
	"smbc.jp", "mufg.jp", "mizuho.jp", "japanpost.jp",
	"nerima.tokyo.jp", "shibuya.tokyo.jp", "shinjuku.tokyo.jp", "minato.tokyo.jp",
}

var domainWords = []string{
	"care", "mail", "tech", "data", "info", "auto", "plan", "node", "core", "form",
	"sync", "push", "base", "bank", "auth", "main", "flow", "tool", "link", "user",
	"help", "pool", "email", "promo", "event", "stats", "batch", "queue", "guide",
	"route", "agent", "chain", "reply", "vault", "store", "group", "order", "entry",
	"setup", "blast", "stage", "score", "cache", "proxy", "admin", "token", "audit",
	"reset", "office", "notify", "alerts", "system", "notice", "report", "mailer",
	"sender", "signal", "client", "search", "config", "update", "member", "action",
	"verify", "stream", "crypto", "daemon", "policy", "server", "branch", "filter",
	"access", "record", "source", "broker", "worker", "engine", "portal", "assist",
	"ticket", "status", "health", "secure", "manage", "safety", "shield", "custom",
	"signup", "backup", "repair", "noreply", "manager", "premium", "monitor", "network",
	"traffic", "checker", "mailbot", "cleaner", "reports", "content", "archive",
	"account", "billing", "payment", "profile", "confirm", "welcome", "service",
	"gateway", "support",
}

var domainSuffixes = []string{
	"corp", "solutions", "systems", "services", "group", "tech", "resolve", "contact",
	"process", "inquiry", "checking", "verifier", "computer", "security", "reminder",
	"messages", "recovery", "dispatch", "delivery", "tracking", "solution", "benefits",
	"endpoint", "notifier", "campaign", "priority", "packages", "progress", "customer",
	"platform", "feedback", "settings", "database", "research", "helpdesk", "response",
	"resource", "pipeline", "workflow", "engineer", "accounts", "firewall", "protocol",
	"incident", "sentinel", "guardian", "operator", "broadcast", "scheduler", "publisher",
	"processor", "connector", "framework", "component", "dashboard", "analytics",
	"collector", "community", "validator", "operation", "management", "onboarding",
	"encryption", "technology", "specialist", "membership", "automation", "middleware",
	"newsletter", "compliance", "statistics", "activation", "checkpoint", "dispatcher",
	"monitoring", "foundation", "protection", "diagnostic", "maintenance", "integration",
	"coordinator", "application", "performance", "information", "confirmation",
	"administrator", "communication", "notifications", "infrastructure", "authentication",
}

// ===== 邮件服务器软件/API标识列表 =====

var mailServerSoftware = []string{
	// ===== 主流邮件服务商API =====
	"Google API",
	"Google SMTP",
	"Google Mail Service",
	"Gmail SMTP",
	"Google Workspace SMTP",
	"Google Apps SMTP",
	"Google Cloud SMTP",
	"Google Relay",
	"Google Mail Relay",
	"Microsoft SMTP",
	"Microsoft SMTP Server",
	"Microsoft Exchange Online",
	"Microsoft 365 SMTP",
	"Office 365 SMTP",
	"Outlook SMTP",
	"Outlook.com SMTP",
	"Exchange SMTP Gateway",
	"Microsoft Exchange Server",
	"Microsoft Exchange Transport",
	"Amazon SES",
	"Amazon SES API",
	"Amazon Simple Email Service",
	"AWS SES SMTP",
	"AWS Mail Service",
	"Amazon SES Relay",
	"SendGrid",
	"SendGrid API",
	"SendGrid SMTP",
	"SendGrid Mail Service",
	"Twilio SendGrid",
	"Mailgun",
	"Mailgun API",
	"Mailgun SMTP",
	"Mailgun Relay",
	"Mailgun Mail Service",
	"Mailchimp",
	"Mailchimp API",
	"Mailchimp Transactional",
	"Mandrill",
	"Mandrill API",
	"Mandrill SMTP",
	"Postmark",
	"Postmark API",
	"Postmark SMTP",
	"Postmark Mail Service",
	"SparkPost",
	"SparkPost API",
	"SparkPost SMTP",
	"SparkPost Relay",
	"Brevo SMTP",
	"Brevo API",
	"Brevo Mail Service",
	"Sendinblue",
	"Sendinblue API",
	"Sendinblue SMTP",
	"Elastic Email",
	"Elastic Email API",
	"Elastic Email SMTP",
	"MailerSend",
	"MailerSend API",
	"MailerSend SMTP",
	"Mailjet",
	"Mailjet API",
	"Mailjet SMTP",
	"Mailjet Relay",
	"Constant Contact",
	"Constant Contact SMTP",
	"Campaign Monitor",
	"Campaign Monitor SMTP",
	"GetResponse",
	"GetResponse SMTP",
	"AWeber",
	"AWeber SMTP",
	"ConvertKit",
	"ConvertKit SMTP",
	"ActiveCampaign",
	"ActiveCampaign SMTP",
	"Drip",
	"Drip SMTP",
	"Klaviyo",
	"Klaviyo SMTP",
	"HubSpot SMTP",
	"HubSpot Mail Service",
	"Salesforce SMTP",
	"Salesforce Marketing Cloud",
	"Oracle Email Delivery",
	"Oracle Cloud SMTP",
	"IBM Cloud Email",
	"SocketLabs",
	"SocketLabs SMTP",
	"SocketLabs API",
	"SMTP2GO",
	"SMTP2GO SMTP",
	"SMTP2GO API",
	"Pepipost",
	"Pepipost SMTP",
	"Pepipost API",
	"Moosend",
	"Moosend SMTP",
	"Omnisend",
	"Omnisend SMTP",
	"Customer.io",
	"Customer.io SMTP",
	"Intercom Mail",
	"Intercom SMTP",
	"Zendesk SMTP",
	"Zendesk Mail Service",
	"Freshdesk SMTP",
	"Freshdesk Mail",

	// ===== MTA邮件服务器软件 =====
	"Postfix",
	"Postfix MTA",
	"Postfix SMTP",
	"Postfix/smtpd",
	"Sendmail",
	"Sendmail MTA",
	"Sendmail/8.15.2",
	"Sendmail/8.16.1",
	"Sendmail/8.17.1",
	"Exim",
	"Exim SMTP",
	"Exim 4.94",
	"Exim 4.96",
	"Exim 4.97",
	"Exim MTA",
	"Dovecot",
	"Dovecot LMTP",
	"Dovecot SMTP",
	"Dovecot/2.3",
	"Zimbra",
	"Zimbra SMTP",
	"Zimbra 8.8",
	"Zimbra 9.0",
	"Zimbra Collaboration",
	"Zimbra MTA",
	"hMailServer",
	"hMailServer 5.6",
	"hMailServer SMTP",
	"Haraka",
	"Haraka SMTP",
	"Haraka MTA",
	"Haraka/2.8",
	"OpenSMTPD",
	"OpenSMTPD 6.8",
	"OpenSMTPD 7.0",
	"qmail",
	"qmail SMTP",
	"qmail-smtpd",
	"Courier",
	"Courier Mail Server",
	"Courier MTA",
	"Courier SMTP",
	"MailEnable",
	"MailEnable SMTP",
	"MailEnable Professional",
	"MailEnable Enterprise",
	"Kerio Connect",
	"Kerio Connect SMTP",
	"Kerio Connect 9.4",
	"IceWarp",
	"IceWarp SMTP",
	"IceWarp Server",
	"IceWarp 13",
	"Axigen",
	"Axigen SMTP",
	"Axigen Mail Server",
	"CommuniGate Pro",
	"CommuniGate Pro SMTP",
	"CommuniGate Pro 6.3",
	"MDaemon",
	"MDaemon SMTP",
	"MDaemon Mail Server",
	"MDaemon 21.5",
	"MDaemon 23.0",
	"Lotus Domino",
	"Lotus Domino SMTP",
	"HCL Domino",
	"HCL Domino SMTP",
	"Novell GroupWise",
	"GroupWise SMTP",
	"GroupWise Internet Agent",
	"PowerMTA",
	"PowerMTA SMTP",
	"PowerMTA/5.0",
	"Apache James",
	"Apache James SMTP",
	"Apache James 3.7",
	"Open-Xchange",
	"Open-Xchange SMTP",
	"Maildrop",
	"Maildrop SMTP",
	"Prosody SMTP",
	"Cyrus SMTP",
	"Cyrus/IMAPd",
	"MailCow",
	"MailCow SMTP",
	"Mailcow Dockerized",
	"Mail-in-a-Box",
	"iRedMail",
	"iRedMail SMTP",
	"Modoboa",
	"Modoboa SMTP",
	"Kolab",
	"Kolab SMTP",
	"Citadel",
	"Citadel SMTP",
	"Hmailserver",

	// ===== 企业/云平台邮件 =====
	"Zoho Mail",
	"Zoho Mail SMTP",
	"Zoho SMTP",
	"Zoho ZeptoMail",
	"Yahoo SMTP",
	"Yahoo Mail SMTP",
	"Yahoo Mail Service",
	"Rackspace Email",
	"Rackspace SMTP",
	"Rackspace Cloud Email",
	"GoDaddy SMTP",
	"GoDaddy Email",
	"GoDaddy Workspace",
	"Fastmail",
	"Fastmail SMTP",
	"Fastmail MTA",
	"ProtonMail",
	"ProtonMail SMTP",
	"ProtonMail Bridge",
	"Proton Mail SMTP",
	"Tutanota",
	"Tutanota SMTP",
	"GMX SMTP",
	"GMX Mail",
	"Mail.Ru SMTP",
	"Mail.Ru",
	"Yandex SMTP",
	"Yandex Mail",
	"Yandex Cloud SMTP",
	"Apple Mail",
	"Apple iCloud Mail",
	"iCloud SMTP",
	"Tencent Mail",
	"Tencent SMTP",
	"QQ Mail SMTP",
	"NetEase Mail",
	"NetEase SMTP",
	"163 Mail SMTP",
	"Alibaba Mail",
	"Alibaba Cloud Mail",
	"Alibaba DirectMail",
	"Naver SMTP",
	"Naver Mail",
	"Daum SMTP",
	"Daum Mail",
	"OVH SMTP",
	"OVH Mail",
	"OVH Cloud Email",
	"Hetzner SMTP",
	"Hetzner Mail",
	"DigitalOcean SMTP",
	"Linode SMTP",
	"Vultr SMTP",
	"Scaleway SMTP",
	"Gandi SMTP",
	"Gandi Mail",
	"Namecheap SMTP",
	"Namecheap Email",
	"Bluehost SMTP",
	"HostGator SMTP",
	"SiteGround SMTP",
	"DreamHost SMTP",
	"Ionos SMTP",
	"1and1 SMTP",
	"Aruba SMTP",
	"Register.it SMTP",

	// ===== 日本邮件服务 =====
	"Sakura Internet",
	"Sakura SMTP",
	"Sakura Mail",
	"GMO SMTP",
	"GMO Mail",
	"GMO Cloud SMTP",
	"KAGOYA SMTP",
	"KAGOYA Mail",
	"KAGOYA Internet",
	"Xserver SMTP",
	"Xserver Mail",
	"Xserver MTA",
	"ConoHa SMTP",
	"ConoHa Mail",
	"ConoHa MTA",
	"IIJ SMTP",
	"IIJ Mail",
	"IIJ Secure MX",
	"BIGLOBE SMTP",
	"BIGLOBE Mail",
	"OCN SMTP",
	"OCN Mail",
	"Nifty SMTP",
	"Nifty Mail",
	"So-net SMTP",
	"So-net Mail",
	"KDDI Mail",
	"KDDI SMTP",
	"au Mail SMTP",
	"NTT Mail SMTP",
	"NTT Communications SMTP",
	"Plala SMTP",
	"Plala Mail",
	"DTI SMTP",
	"DTI Mail",
	"Interlink SMTP",
	"WebARENA SMTP",
	"WADAX SMTP",
	"CPI SMTP",
	"Lolipop SMTP",
	"Lolipop Mail",
	"MuuMuu SMTP",
	"Onamae SMTP",
	"Onamae Mail",
	"ValueServer SMTP",
	"Core Server SMTP",
	"Heteml SMTP",

	// ===== 安全网关/邮件过滤器 =====
	"Barracuda",
	"Barracuda SMTP",
	"Barracuda Email Gateway",
	"Barracuda Spam Firewall",
	"Proofpoint",
	"Proofpoint SMTP",
	"Proofpoint Protection",
	"Proofpoint Essentials",
	"Proofpoint Gateway",
	"Sophos Email",
	"Sophos SMTP",
	"Sophos Email Appliance",
	"Symantec Messaging Gateway",
	"Symantec SMTP",
	"Broadcom Email Security",
	"FortiMail",
	"FortiMail SMTP",
	"Fortinet FortiMail",
	"Cisco IronPort",
	"Cisco ESA",
	"Cisco Email Security",
	"Cisco SMTP",
	"Trend Micro",
	"Trend Micro SMTP",
	"Trend Micro Email Security",
	"Trend Micro IMSVA",
	"SpamAssassin",
	"Amavis",
	"Amavisd-new",
	"Amavis SMTP",
	"Mimecast",
	"Mimecast SMTP",
	"Mimecast Gateway",
	"Mimecast Email Security",
	"Cloudmark",
	"Cloudmark SMTP",
	"McAfee Email Gateway",
	"McAfee SMTP",
	"Trellix Email Security",
	"FireEye SMTP",
	"FireEye Email Security",
	"Palo Alto SMTP",
	"Juniper SMTP",
	"F-Secure SMTP",
	"ESET Mail Security",
	"ESET SMTP",
	"Kaspersky SMTP",
	"Kaspersky Security for Mail",
	"Bitdefender SMTP",
	"Avira SMTP",
	"ClamAV SMTP",
	"Rspamd",
	"Rspamd SMTP",
	"MailScanner",
	"MailScanner SMTP",
	"SpamTitan",
	"SpamTitan SMTP",
	"MailGuard SMTP",
	"N-able Mail Assure",
	"SolarWinds Mail Assure",
	"Hornetsecurity",
	"Hornetsecurity SMTP",
	"Retarus SMTP",
	"Retarus Email Security",
	"Zix SMTP",
	"Zix Email Encryption",
	"Virtru SMTP",
	"Egress SMTP",
	"Libraesva SMTP",
	"Libraesva ESG",
	"GFI MailEssentials",
	"GFI SMTP",
	"Spam Experts",
	"SpamExperts SMTP",

	// ===== 开发框架/库 =====
	"PHPMailer",
	"PHPMailer SMTP",
	"SwiftMailer",
	"SwiftMailer SMTP",
	"Symfony Mailer",
	"Laravel SMTP",
	"Django SMTP",
	"Rails SMTP",
	"Nodemailer",
	"Nodemailer SMTP",
	"JavaMail",
	"JavaMail SMTP",
	"Jakarta Mail",
	"Jakarta Mail SMTP",
	"Spring Mail",
	"Spring SMTP",
	"Python smtplib",
	"Go net/smtp",
	"Ruby Net::SMTP",
	"Perl Net::SMTP",

	// ===== 虚拟/通用标识 =====
	"SMTP Gateway",
	"SMTP Relay",
	"SMTP Service",
	"Mail Gateway",
	"Mail Relay",
	"Mail Service",
	"Mail Transfer Agent",
	"MTA Gateway",
	"MTA Relay",
	"MTA Service",
	"Email Gateway",
	"Email Relay",
	"Email Service",
	"Outbound SMTP",
	"Outbound Relay",
	"Inbound SMTP",
	"Cloud SMTP",
	"Cloud Mail",
	"Cloud Relay",
	"Managed SMTP",
	"Managed Mail Service",
	"Secure SMTP",
	"Secure Mail Gateway",
	"Enterprise SMTP",
	"Enterprise Mail",
	"Corporate SMTP",
	"Corporate Mail Gateway",
	"Dedicated SMTP",
	"Hosted SMTP",
	"Hosted Mail Service",
	"Private SMTP",
	"Internal SMTP",
	"Local MTA",
	"Relay SMTP",
	"Smarthost SMTP",
	"Submission SMTP",
	"MSA SMTP",
	"MX Gateway",
	"MX Relay",
	"MX Service",
	"Mail Hub",
	"Mail Proxy",
	"Mail Router",
	"Mail Bridge",
	"Mail Dispatcher",
	"Mail Processor",
	"Mail Handler",
	"SMTP Processor",
	"SMTP Dispatcher",
	"SMTP Handler",
	"SMTP Forwarder",
	"SMTP Router",
	"SMTP Proxy",
	"SMTP Bridge",
	"SMTP Hub",
	"Messaging Gateway",
	"Messaging Service",
	"Messaging Relay",
	"Message Transfer",
	"Message Router",
	"Message Gateway",
	"Delivery Service",
	"Delivery Gateway",
	"Delivery Agent",
	"Delivery Relay",
	"Transaction Mail",
	"Transactional SMTP",
	"Bulk Mail Service",
	"Mass Mail Service",
	"Notification Service",
	"Notification SMTP",
	"Alert Service",
	"Alert SMTP",
}
