package config

import (
	"fmt"
	"os"
	"runtime"

	"gopkg.in/yaml.v3"
)

// Config 主配置结构
type Config struct {
	App         AppConfig         `yaml:"app"`
	MtaType     string            `yaml:"mta_type"` // "pmta" 或 "haraka"，控制邮件头行为
	Sender      SenderConfig      `yaml:"sender"`
	PMTA        PMTAConfig        `yaml:"pmta"`
	SMTP        SMTPConfig        `yaml:"smtp"`
	Performance PerformanceConfig `yaml:"performance"`
	Email       EmailConfig       `yaml:"email"`
	Attachments AttachmentsConfig `yaml:"attachments"`
	Recipients  RecipientsConfig  `yaml:"recipients"`
	Job         JobConfig         `yaml:"job"`
	Output      OutputConfig      `yaml:"output"`
	Template    TemplateConfig    `yaml:"template"`
	Encoding    EncodingConfig    `yaml:"encoding"`
	Variables   VariablesConfig   `yaml:"variables"`
	Headers     HeadersConfig     `yaml:"headers"`
	DryRun      bool              `yaml:"-"`
}

type AppConfig struct {
	Name     string `yaml:"name"`
	Version  string `yaml:"version"`
	LogLevel string `yaml:"log_level"`
	LogFile  string `yaml:"log_file"`
}

type SenderConfig struct {
	Mode            string   `yaml:"mode"`
	FromAddress     string   `yaml:"from_address"`
	FromName        string   `yaml:"from_name"`
	EnvelopeFrom    string   `yaml:"envelope_from"`
	ReplyTo         string   `yaml:"reply_to"`
	DisplayNames    []string `yaml:"display_names"`
	DisplayNameMode string   `yaml:"display_name_mode"`
}

type PMTAConfig struct {
	VirtualMTA string `yaml:"virtual_mta"`
	PickupDir  string `yaml:"pickup_dir"`
	TempDir    string `yaml:"temp_dir"`
	FileMode   uint32 `yaml:"file_mode"`
	DirMode    uint32 `yaml:"dir_mode"`
}

type SMTPConfig struct {
	Enabled    bool   `yaml:"enabled"`
	Host       string `yaml:"host"`
	Port       int    `yaml:"port"`
	UseAuth    bool   `yaml:"use_auth"`
	Username   string `yaml:"username"`
	Password   string `yaml:"password"`
	UseTLS     bool   `yaml:"use_tls"`
	SkipVerify bool   `yaml:"skip_verify"`
	Timeout    int    `yaml:"timeout"`
	MaxConn    int    `yaml:"max_conn"`
}

type PerformanceConfig struct {
	Workers          int `yaml:"workers"`
	RateLimit        int `yaml:"rate_limit"`
	BatchSize        int `yaml:"batch_size"`
	ChannelBuffer    int `yaml:"channel_buffer"`
	MemoryWarningMB  int `yaml:"memory_warning_mb"`
	ProgressInterval int `yaml:"progress_interval"`
	MinInterval      int `yaml:"min_interval"`
	MaxInterval      int `yaml:"max_interval"`
	BatchPause       int `yaml:"batch_pause"`
	RetryCount       int `yaml:"retry_count"`
	RetryInterval    int `yaml:"retry_interval"`
}

type EmailConfig struct {
	Subject          string               `yaml:"subject"`
	Subjects         []string             `yaml:"subjects"`
	SubjectMode      string               `yaml:"subject_mode"`
	TemplatePath     string               `yaml:"template_path"`
	TemplatePaths    []string             `yaml:"template_paths"`
	TemplateMode     string               `yaml:"template_mode"`
	ConvertTxtToHtml bool                 `yaml:"convert_txt_to_html"`
	Charset          string               `yaml:"charset"`
	ContentType      string               `yaml:"content_type"`
	IncludeTextPart  bool                 `yaml:"include_text_part"`
	MimeMode         string               `yaml:"mime_mode"` // "standard" | "alternative" | "full"
	CustomHeaders    map[string]string    `yaml:"custom_headers"`
	EmbeddedImages   []EmbeddedImageConfig `yaml:"embedded_images"` // 【Haraka24】CID 内嵌图片
}

// 【Haraka24】CID 内嵌图片配置
type EmbeddedImageConfig struct {
	CID         string `yaml:"cid"`          // Content-ID 标识（对应 HTML 里的 cid:xxx）
	Path        string `yaml:"path"`         // 图片文件路径
	ContentType string `yaml:"content_type"` // MIME 类型（image/png, image/jpeg 等）
}

type AttachmentsConfig struct {
	Enabled bool     `yaml:"enabled"`
	Mode    string   `yaml:"mode"`
	Files   []string `yaml:"files"`
}

type RecipientsConfig struct {
	FilePath         string    `yaml:"file_path"`
	Format           string    `yaml:"format"`
	SkipLines        int       `yaml:"skip_lines"`
	CSV              CSVConfig `yaml:"csv"`
	RemoveDuplicates bool      `yaml:"remove_duplicates"`
	FilterInvalid    bool      `yaml:"filter_invalid"`
}

type CSVConfig struct {
	Delimiter    string            `yaml:"delimiter"`
	HasHeader    bool              `yaml:"has_header"`
	FieldMapping map[string]string `yaml:"field_mapping"`
}

type JobConfig struct {
	ID              string `yaml:"id"`
	IDPrefix        string `yaml:"id_prefix"`
	IncludeInHeader bool   `yaml:"include_in_header"`
}

type OutputConfig struct {
	ProgressInterval int    `yaml:"progress_interval"`
	ShowProgressBar  bool   `yaml:"show_progress_bar"`
	ProgressFile     string `yaml:"progress_file"`
	ResultFile       string `yaml:"result_file"`
	ErrorFile        string `yaml:"error_file"`
	SaveLog          bool   `yaml:"save_log"`
	SaveFailedEmails bool   `yaml:"save_failed_emails"`
	LogDirectory     string `yaml:"log_directory"`
}

type TemplateConfig struct {
	GlobalVariables map[string]interface{} `yaml:"global_variables"`
}

type EncodingConfig struct {
	Charset        string `yaml:"charset"`
	HeaderEncoding string `yaml:"header_encoding"`
	BodyEncoding   string `yaml:"body_encoding"`
	RandomEncoding bool   `yaml:"random_encoding"`
}

type VariablesConfig struct {
	AmountMin           float64           `yaml:"amount_min"`
	AmountMax           float64           `yaml:"amount_max"`
	AmountDecimals      int               `yaml:"amount_decimals"`
	AmountUseSeparator  bool              `yaml:"amount_use_separator"`
	CustomVariableFiles map[string]string `yaml:"custom_variable_files"`
}

type HeadersConfig struct {
	Enabled           bool   `yaml:"enabled"`
	Received          bool   `yaml:"received"`
	DkimSignature     bool   `yaml:"dkim_signature"`
	XMailer           bool   `yaml:"x_mailer"`
	XPriority         bool   `yaml:"x_priority"`
	XPriorityValue    string `yaml:"x_priority_value"`
	Importance        bool   `yaml:"importance"`
	ImportanceValue   string `yaml:"importance_value"`
	MessageID         bool   `yaml:"message_id"`
	ReplyTo           bool   `yaml:"reply_to"`
	ReplyToMode       string `yaml:"reply_to_mode"`
	ReturnPath        bool   `yaml:"return_path"`
	ReturnPathMode    string `yaml:"return_path_mode"`
	AcceptLanguage    bool   `yaml:"accept_language"`
	AcceptLangValue   string `yaml:"accept_language_value"`
	ContentLanguage   bool   `yaml:"content_language"`
	ContentLangValue  string `yaml:"content_language_value"`
	CustomHeadersText string `yaml:"custom_headers_text"`
}

// IsPMTA 判断是否为 PowerMTA 模式
func (c *Config) IsPMTA() bool {
	return c.MtaType == "" || c.MtaType == "pmta"
}

// IsHaraka 判断是否为 Haraka 模式
func (c *Config) IsHaraka() bool {
	return c.MtaType == "haraka"
}

func Default() *Config {
	return &Config{
		App: AppConfig{
			Name: "pmta-injector", Version: "2.0.0",
			LogLevel: "info", LogFile: "/var/log/pmta-injector/app.log",
		},
		MtaType: "pmta",
		Sender: SenderConfig{
			Mode: "auto", FromAddress: "noreply@example.com", FromName: "Example Company",
			DisplayNames: []string{}, DisplayNameMode: "random",
		},
		PMTA: PMTAConfig{
			VirtualMTA: "pmta-vmta1", PickupDir: "/var/spool/pmta/pickup",
			TempDir: "/var/spool/pmta/tmp", FileMode: 0644, DirMode: 0755,
		},
		SMTP: SMTPConfig{
			Enabled: true, Host: "127.0.0.1", Port: 25,
			UseAuth: false, UseTLS: false, SkipVerify: true, Timeout: 30, MaxConn: 50,
		},
		Performance: PerformanceConfig{
			Workers: runtime.NumCPU() * 10, BatchSize: 1000, ChannelBuffer: 10000,
			MemoryWarningMB: 500, ProgressInterval: 1, MaxInterval: 100,
			BatchPause: 5, RetryCount: 3, RetryInterval: 1000,
		},
		Email: EmailConfig{
			Subject: "Welcome", Subjects: []string{}, SubjectMode: "random",
			TemplatePaths: []string{}, TemplateMode: "random", ConvertTxtToHtml: true,
			Charset: "UTF-8", ContentType: "text/html", MimeMode: "standard", CustomHeaders: make(map[string]string),
		},
		Attachments: AttachmentsConfig{Mode: "sequential", Files: []string{}},
		Recipients: RecipientsConfig{
			Format: "auto", RemoveDuplicates: true, FilterInvalid: true,
			CSV: CSVConfig{Delimiter: ",", HasHeader: true, FieldMapping: map[string]string{}},
		},
		Job:      JobConfig{IDPrefix: "job", IncludeInHeader: true},
		Output: OutputConfig{
			ProgressInterval: 1, ShowProgressBar: true,
			ProgressFile: "/tmp/progress.json", ResultFile: "/tmp/result.json",
			ErrorFile: "/tmp/errors.log", SaveLog: true, SaveFailedEmails: true,
			LogDirectory: "/var/log/pmta-injector",
		},
		Template: TemplateConfig{GlobalVariables: make(map[string]interface{})},
		Encoding: EncodingConfig{Charset: "UTF-8", HeaderEncoding: "base64", BodyEncoding: "base64"},
		Variables: VariablesConfig{
			AmountMin: 10000, AmountMax: 100000, AmountUseSeparator: true,
			CustomVariableFiles: make(map[string]string),
		},
		Headers: HeadersConfig{
			XPriorityValue: "random", ImportanceValue: "random",
			ReplyToMode: "from_address", ReturnPathMode: "from_address",
			AcceptLangValue: "random", ContentLangValue: "random",
		},
	}
}

func LoadFromFile(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("读取配置文件失败: %w", err)
	}
	cfg := Default()
	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, fmt.Errorf("解析配置文件失败: %w", err)
	}
	if cfg.Sender.EnvelopeFrom == "" {
		cfg.Sender.EnvelopeFrom = cfg.Sender.FromAddress
	}
	if cfg.Performance.Workers <= 0 {
		cfg.Performance.Workers = runtime.NumCPU() * 10
	}
	return cfg, nil
}

func (c *Config) Save(path string) error {
	data, err := yaml.Marshal(c)
	if err != nil {
		return fmt.Errorf("序列化配置失败: %w", err)
	}
	if err := os.WriteFile(path, data, 0644); err != nil {
		return fmt.Errorf("写入配置文件失败: %w", err)
	}
	return nil
}
