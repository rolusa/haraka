package email

// =============================================================================
// 【2026-05-27 从 PowerMTA 移植】50 个 Received 模板模板（"Received（随机）"功能内置池）
//
// 设计：
//   每个模板是一个"风格模板"，含 5-15 个变量占位符（{IP_*} / {DOMAIN_*} / {ID_*} /
//   {RFC2822_*} / {TLS_*} / {SMTP_PROTOCOL} 等），运行时由 VariableProcessor 渲染。
//   50 个模板 × 平均 8 个变量位置 × 每个变量平均 100 种取值 = 数万亿级变体。
//
// 类别分布（共 50 条，按真实邮件 Received 频谱加权）：
//   - Yahoo 系                4 (idx 0-3)
//   - Yahoo gateway 系        2 (idx 4-5)
//   - Gmail SMTP 系           4 (idx 6-9)
//   - Docomo bill 系          3 (idx 10-12)
//   - Docomo mfsmax 系        2 (idx 13-14)
//   - Postfix 通用            5 (idx 15-19)
//   - Mitsui vpass / smbc     2 (idx 20-21)
//   - Biccamera / ml          2 (idx 22-23)
//   - L-Tike                  1 (idx 24)
//   - Microsoft / Office365   4 (idx 25-28)
//   - Amazon SES              3 (idx 29-31)
//   - SendGrid / Mailgun      4 (idx 32-35)
//   - 企业 Exchange           4 (idx 36-39)
//   - Au                      2 (idx 40-41)
//   - Softbank                2 (idx 42-43)
//   - Yodobashi / 乐天        3 (idx 44-46)
//   - 杂项 (Exim / Sendmail)  3 (idx 47-49)
//
// 总计：4+2+4+3+2+5+2+2+1+4+3+4+4+2+2+3+3 = 50 ✓
//
// 约定：
//   - 每个模板都是单行（不含 \r\n），渲染后由 foldHeaderValue 折叠
//   - 不含 "Received: " 前缀（由调用方拼接）
//   - 所有变量占位符必须能被 variables_ext.go 中的 53 个变量解析
//   - 模板内部不嵌套变量（如 `{ID_HEX:{TIMESTAMP}}` 这种），避免循环替换
// =============================================================================

// receivedTemplatePool 50 个 Received 模板（按上述类别顺序）
// 模板里 {VAR} 是变量占位符，会被 variables_ext.go 的 vp.Process 替换
var receivedTemplatePool = []string{
	// ===== Yahoo 系（4 个）=====
	// idx 0: 用户示例 1 的范式
	"from {IP_YAHOO_JP}  (EHLO {DOMAIN_YAHOO_EHLO}) ({IP_YAHOO_JP}) by {DOMAIN_YAHOO_MX} with SMTP; {RFC2822_DATE_JST}",
	// idx 1: 不带 EHLO 的简化版
	"from {DOMAIN_YAHOO_EHLO} ({IP_YAHOO_JP}) by {DOMAIN_YAHOO_MX} with ESMTP; {RFC2822_DATE_JST}",
	// idx 2: 带 for <收件人> 的扩展版
	"from {IP_YAHOO_JP}  (EHLO {DOMAIN_YAHOO_EHLO}) ({IP_YAHOO_JP}) by {DOMAIN_YAHOO_MX} with SMTP id {ID_QUEUE:16} for <{TO_EMAIL}>; {RFC2822_DATE_JST}",
	// idx 3: TLS 信息完整
	"from {DOMAIN_YAHOO_EHLO} ({IP_YAHOO_JP}) by {DOMAIN_YAHOO_MX} with ESMTPS id {ID_HEX:20} (version={TLS_VERSION} cipher={TLS_CIPHER} bits={TLS_BITS}) for <{TO_EMAIL}>; {RFC2822_DATE_JST}",

	// ===== Yahoo gateway 系（2 个）=====
	// idx 4: 用户示例 10 的范式（goats.kks.ynwl）
	"from {DOMAIN_YAHOO_GW} ({DOMAIN_YAHOO_GW} [{IP_PUBLIC_GLOBAL}]) by {DOMAIN_YAHOO_EHLO} (Postfix) with ESMTPS id {ID_POSTFIX_LONG} for <{TO_EMAIL}>; {RFC2822_DATE_WITH_JST}",
	// idx 5: Yahoo gateway 简化版
	"from {DOMAIN_YAHOO_GW} ([{IP_PUBLIC_GLOBAL}]) by {DOMAIN_YAHOO_EHLO} (Postfix) with ESMTP id {ID_POSTFIX_LONG}; {RFC2822_DATE_JST}",

	// ===== Gmail SMTP 系（4 个）=====
	// idx 6: 用户示例 3 的范式（da.direct）
	"from {DOMAIN_GMAIL_HOST} ([{IP_PUBLIC_GLOBAL}]) by {DOMAIN_GMAIL_OUT} with ESMTPSA id {ID_GMAIL} for <{TO_EMAIL}> (version={TLS_VERSION} cipher={TLS_CIPHER} bits={TLS_BITS}); {RFC2822_DATE_PDT}",
	// idx 7: Gmail 标准 ESMTPS
	"from {DOMAIN_GMAIL_OUT} ({IP_GMAIL_GW}) by {DOMAIN_GMAIL_OUT} with ESMTPS id {ID_GMAIL}; {RFC2822_DATE_PST}",
	// idx 8: Gmail mail-XX 出口
	"from {DOMAIN_GMAIL_OUT} ([{IP_GMAIL_GW}]) by mx.google.com with ESMTPS id {ID_GMAIL} for <{TO_EMAIL}>; {RFC2822_DATE_PST}",
	// idx 9: Gmail SMTPS with TLS
	"from {DOMAIN_GMAIL_OUT} (HELO {DOMAIN_GMAIL_OUT}) ([{IP_GMAIL_GW}]) by smtp.gmail.com with ESMTPS id {ID_GMAIL} (Google Transport Security); {RFC2822_DATE_PDT}",

	// ===== Docomo bill 系（3 个）=====
	// idx 10: 用户示例 4 的范式
	"from localhost (localhost [{IP_LOOPBACK}]) by {DOMAIN_DOCOMO_BILL}(2.20.1.0.0) with SMTP; {RFC2822_DATE_WITH_JST}",
	// idx 11: 用户示例 5 的范式（双 docomo）
	"from {DOMAIN_DOCOMO_BILL} (localhost [{IP_LOOPBACK}]) by {DOMAIN_DOCOMO_LOCAL} (Postfix) with ESMTP id {ID_QUEUE:13} for <{TO_EMAIL}>; {RFC2822_DATE_WITH_JST}",
	// idx 12: docomo-bill 带 by 内部 IP
	"from {DOMAIN_DOCOMO_BILL} ([{IP_DOCOMO_INTERNAL}]) by {DOMAIN_DOCOMO_LOCAL} (Postfix) with ESMTP id {ID_POSTFIX_LONG}; {RFC2822_DATE_WITH_JST}",

	// ===== Docomo mfsmax 系（2 个）=====
	// idx 13: 用户示例 8 的范式
	"from {DOMAIN_YODOBASHI} ([{IP_PUBLIC_GLOBAL}]) by {DOMAIN_DOCOMO_MFSMAX}(DOCOMO Mail Server Ver2.0) with SMTP id {ID_HEX:20} for <{TO_USER}>; {RFC2822_DATE_WITH_JST}",
	// idx 14: mfsmax 简化
	"from {DOMAIN_YODOBASHI} by {DOMAIN_DOCOMO_MFSMAX}(DOCOMO Mail Server Ver2.0) with SMTP id {ID_HEX:18}; {RFC2822_DATE_WITH_JST}",

	// ===== Postfix 通用（5 个）=====
	// idx 15: 用户示例 6 的范式
	"from elimmf01 (unknown [{IP_PRIVATE_10}]) by {DOMAIN_LTIKE} (Postfix) with ESMTP id {ID_QUEUE:13} for <{TO_EMAIL}>; {RFC2822_DATE_WITH_JST}",
	// idx 16: Postfix unknown 私网
	"from unknown ({IP_PRIVATE_172}) by mx.{FROM_DOMAIN} (Postfix) with ESMTP id {ID_QUEUE:11} for <{TO_EMAIL}>; {RFC2822_DATE_JST}",
	// idx 17: Postfix 反向 DNS 解析
	"from mail-{ID_HEX:8}.{FROM_DOMAIN} ([{IP_PUBLIC_GLOBAL}]) by relay.{FROM_DOMAIN} (Postfix) with ESMTPS id {ID_QUEUE:13} for <{TO_EMAIL}>; {RFC2822_DATE}",
	// idx 18: Postfix 带版本号
	"from mta-{ID_HEX:4}.{FROM_DOMAIN} ({IP_PUBLIC_GLOBAL}) by mx.{FROM_DOMAIN} (Postfix-2.11.7) with ESMTP id {ID_QUEUE:11}; {RFC2822_DATE_JST}",
	// idx 19: Postfix queue id only
	"by mx.{FROM_DOMAIN} (Postfix) with ESMTP id {ID_POSTFIX_LONG} for <{TO_EMAIL}>; {RFC2822_DATE}",

	// ===== Mitsui vpass / smbc（2 个）=====
	// idx 20: 用户示例 2 的范式
	"by mta.contact.vpass.ne.jp id {ID_BICCAMERA} for <{TO_EMAIL}>; {RFC2822_DATE_UTC} (envelope-from <bounce-{ID_BOUNCE_TOKEN}@bounce.contact.vpass.ne.jp>)",
	// idx 21: Mitsui SMBC
	"from {DOMAIN_MITSUI} by {DOMAIN_MITSUI} with SMTP id {ID_HEX:18}; {RFC2822_DATE_WITH_JST}",

	// ===== Biccamera / ml（2 个）=====
	// idx 22: 用户示例 7 的范式
	"by {DOMAIN_BICCAMERA} id {ID_BICCAMERA} for <{TO_EMAIL}>; {RFC2822_DATE_UTC} (envelope-from <bounce-{ID_BOUNCE_TOKEN}@bounce.ml.biccamera.com>)",
	// idx 23: Biccamera 简化
	"from mta.{ID_HEX:4}.biccamera.com ({IP_PUBLIC_GLOBAL}) by mx.biccamera.com (Postfix) with ESMTP id {ID_BICCAMERA}; {RFC2822_DATE_JST}",

	// ===== L-Tike（1 个）=====
	// idx 24: 用户示例 6 升级版（含 envelope-from）
	"from elimmf{ID_HEX:2} (unknown [{IP_PRIVATE_10}]) by {DOMAIN_LTIKE} (Postfix) with ESMTP id {ID_QUEUE:13} (envelope-from <noreply@l-tike.com>) for <{TO_EMAIL}>; {RFC2822_DATE_WITH_JST}",

	// ===== Microsoft / Office365（4 个）=====
	// idx 25: Office365 outbound
	"from {ID_HEX:4}.outbound.protection.outlook.com ({IP_PUBLIC_GLOBAL}) by mx.{TO_DOMAIN} with Microsoft SMTP Server (version={TLS_VERSION} cipher={TLS_CIPHER} bits={TLS_BITS}) id 15.20.{ID_QUEUE:4}.18 via Frontend Transport; {RFC2822_DATE_UTC}",
	// idx 26: Outlook.com 出站
	"from MWHPR{ID_QUEUE:2}MB{ID_QUEUE:4}.namprd{ID_QUEUE:2}.prod.outlook.com ({ID_HEX:4}::{ID_HEX:4}:{ID_HEX:4}:{ID_HEX:4}:{ID_HEX:4}) by MWHPR{ID_QUEUE:2}MB{ID_QUEUE:4}.namprd{ID_QUEUE:2}.prod.outlook.com with HTTPS; {RFC2822_DATE_UTC}",
	// idx 27: Exchange Online ESMTPS
	"from NAM{ID_HEX:2}-{ID_HEX:4}-obe.outbound.protection.outlook.com ({IP_PUBLIC_GLOBAL}) by mx.{TO_DOMAIN} with ESMTPS id {ID_QUEUE:11} (version={TLS_VERSION} cipher={TLS_CIPHER}); {RFC2822_DATE_UTC}",
	// idx 28: Microsoft 中转
	"from {ID_HEX:8}-{ID_HEX:4}-{ID_HEX:4}-{ID_HEX:4}-{ID_HEX:12} by smtp.office365.com (Microsoft SMTP Server) with ESMTPS id {ID_QUEUE:11}; {RFC2822_DATE_UTC}",

	// ===== Amazon SES（3 个）=====
	// idx 29: SES 标准出站
	"from {DOMAIN_AMAZONSES_OUT} ({DOMAIN_AMAZONSES_OUT} [{IP_AWS_SES}]) by mx.{TO_DOMAIN} with SMTP id {ID_AMAZON_SES} for <{TO_EMAIL}>; {RFC2822_DATE_UTC}",
	// idx 30: SES with ESMTPS + TLS
	"from {DOMAIN_AMAZONSES_OUT} ([{IP_AWS_SES}]) by mx.{TO_DOMAIN} with ESMTPS id {ID_AMAZON_SES} (version={TLS_VERSION} cipher={TLS_CIPHER} bits={TLS_BITS}); {RFC2822_DATE_UTC}",
	// idx 31: SES short queue id
	"by {DOMAIN_AMAZONSES_OUT} with ESMTP id {ID_HEX:20}; {RFC2822_DATE_UTC}",

	// ===== SendGrid / Mailgun（4 个）=====
	// idx 32: SendGrid outbound
	"from o{ID_QUEUE:6}.outbound-mail.sendgrid.net (o{ID_QUEUE:6}.outbound-mail.sendgrid.net [{IP_PUBLIC_GLOBAL}]) by mx.{TO_DOMAIN} (Postfix) with ESMTPS id {ID_QUEUE:11} for <{TO_EMAIL}> (version={TLS_VERSION} cipher={TLS_CIPHER}); {RFC2822_DATE_UTC}",
	// idx 33: SendGrid simple
	"from wrapper-{ID_HEX:4} ([{IP_PUBLIC_GLOBAL}]) by mx.sendgrid.net with ESMTP id {ID_HEX:12}; {RFC2822_DATE_UTC}",
	// idx 34: Mailgun outbound
	"from mxa-{ID_HEX:8}.mailgun.org ([{IP_PUBLIC_GLOBAL}]) by mx.{TO_DOMAIN} (Postfix) with ESMTPS id {ID_QUEUE:11}; {RFC2822_DATE_UTC}",
	// idx 35: Mandrill / SparkPost 风格
	"from {ID_HEX:8}.mta1vrest.cc.prd.sparkpost ([{IP_PUBLIC_GLOBAL}]) by mx.{TO_DOMAIN} with ESMTPS id {ID_QUEUE:11}; {RFC2822_DATE_UTC}",

	// ===== 企业 Exchange（4 个）=====
	// idx 36: 大型企业 EDGE
	"from EX-EDGE-{ID_QUEUE:2}.corp.{FROM_DOMAIN} ({IP_PRIVATE_10}) by EX-MBX-{ID_QUEUE:2}.corp.{FROM_DOMAIN} with Microsoft SMTP Server (version={TLS_VERSION} cipher={TLS_CIPHER}) id 15.1.{ID_QUEUE:4}.{ID_QUEUE:2}; {RFC2822_DATE}",
	// idx 37: Exchange edge transport
	"from EXCH-{ID_HEX:4}.{FROM_DOMAIN} ([{IP_PRIVATE_192}]) by mail.{FROM_DOMAIN} with Microsoft SMTPSVC(8.5.{ID_QUEUE:4}.0); {RFC2822_DATE}",
	// idx 38: Exchange + cluster
	"from EXMBX{ID_QUEUE:2}.{FROM_DOMAIN} ({IP_PRIVATE_10}) by EXEDGE{ID_QUEUE:2}.{FROM_DOMAIN} with Microsoft SMTP Server id 15.0.{ID_QUEUE:4}.{ID_QUEUE:2} via Mailbox Transport; {RFC2822_DATE_UTC}",
	// idx 39: Lotus Notes 风
	"from mail.{FROM_DOMAIN} (Lotus Domino Release 9.0.{ID_HEX:1} HF{ID_QUEUE:3}) by mx.{TO_DOMAIN} (NotesPump 9.0) with SMTP; {RFC2822_DATE}",

	// ===== au（2 个）=====
	// idx 40: au with id
	"from mail.au.com by {DOMAIN_AU} with ESMTP id <{ID_HEX:17}.AAAA.{ID_QUEUE:5}.mail.au.com@{DOMAIN_AU}> for <{TO_EMAIL}>; {RFC2822_DATE_JST}",
	// idx 41: au snd simple
	"from {DOMAIN_AU} ([{IP_PRIVATE_10}]) by {DOMAIN_AU} (Postfix) with ESMTP id {ID_POSTFIX_LONG}; {RFC2822_DATE_JST}",

	// ===== Softbank（2 个）=====
	// idx 42: Softbank ebmky 三段式
	"from {DOMAIN_SOFTBANK_EBMKY} ([{IP_SOFTBANK_172}]) by {DOMAIN_SOFTBANK_EBMKY} with Microsoft SMTPSVC; {RFC2822_DATE_JST}",
	// idx 43: Softbank dimky biz
	"from dimky{ID_QUEUE:3}sb.softbank.ad.jp ([{IP_SOFTBANK_172}]) by ebmky{ID_QUEUE:3}sc.softbank.ad.jp (Postfix) with ESMTP id {ID_QUEUE:11}; {RFC2822_DATE_JST}",

	// ===== Yodobashi / 乐天（3 个）=====
	// idx 44: Yodobashi 内部
	"from {DOMAIN_YODOBASHI} ({DOMAIN_YODOBASHI} [{IP_PUBLIC_GLOBAL}]) by mx.{TO_DOMAIN} (Postfix) with ESMTPS id {ID_QUEUE:11}; {RFC2822_DATE_WITH_JST}",
	// idx 45: 乐天 Rakuten
	"from mta-{ID_QUEUE:4}.smtp.rakuten.co.jp ([{IP_PUBLIC_GLOBAL}]) by mx.{TO_DOMAIN} (Postfix) with ESMTPS id {ID_QUEUE:11} for <{TO_EMAIL}>; {RFC2822_DATE_JST}",
	// idx 46: LINE 通讯
	"from oproxy{ID_QUEUE:2}-{ID_QUEUE:5}.line.me ([{IP_PUBLIC_GLOBAL}]) by mx.{TO_DOMAIN} with ESMTPS id {ID_QUEUE:11} (version={TLS_VERSION} cipher={TLS_CIPHER}); {RFC2822_DATE_JST}",

	// ===== 杂项（Exim / Sendmail）（3 个）=====
	// idx 47: Exim queue
	"from [{IP_PUBLIC_GLOBAL}] (helo=mail.{FROM_DOMAIN}) by mx.{TO_DOMAIN} with esmtps (TLSv1.3:TLS_AES_256_GCM_SHA384:256) (Exim 4.94.2) (envelope-from <noreply@{FROM_DOMAIN}>) id {ID_EXIM_QUEUE} for <{TO_EMAIL}>; {RFC2822_DATE}",
	// idx 48: Sendmail 8.x
	"from {FROM_DOMAIN} (mail.{FROM_DOMAIN} [{IP_PUBLIC_GLOBAL}]) by mx.{TO_DOMAIN} (8.15.2/8.15.2) with ESMTPS id {ID_QUEUE:11} (version={TLS_VERSION} cipher={TLS_CIPHER}); {RFC2822_DATE}",
	// idx 49: qmail / qmqp 老派
	"from {FROM_DOMAIN} (HELO mail.{FROM_DOMAIN}) ({IP_PUBLIC_GLOBAL}) by mx.{TO_DOMAIN} with SMTP id {ID_QUEUE:13}; {RFC2822_DATE}",
}

// receivedTemplatePoolSize 池大小（启动时一次性计算，避免运行时反复求 len）
var receivedTemplatePoolSize = len(receivedTemplatePool)
