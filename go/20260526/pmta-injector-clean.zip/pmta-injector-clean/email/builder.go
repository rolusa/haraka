package email

import (
	"encoding/base64"
	"fmt"
	"math/rand"
	"mime/quotedprintable"
	"regexp"
	"strings"
	"time"
	"unicode/utf8"

	"__MODULE_PLACEHOLDER__/config"
	"__MODULE_PLACEHOLDER__/types"
	"__MODULE_PLACEHOLDER__/utils"
)

// Email 邮件结构
type Email struct {
	// 信封信息
	EnvelopeFrom string
	EnvelopeTo   string
	VirtualMTA   string
	JobID        string

	// 邮件头
	From      string
	To        string
	Subject   string
	Date      time.Time
	MessageID string

	// 【2026-05-27 从 PowerMTA 移植】主邮件的 Cc 头(已 RFC 5322 编码,逗号分隔多个地址)
	// 仅主邮件构建时由 Build 根据 BuildOptions.CcHeaderList 填充
	// CC/BCC 独立邮件构建时 CcHeader 为空,buildRawEmail 跳过 Cc 头输出
	// (BCC 永远不出现在 raw 中,所以这里没有 BccHeader 字段)
	CcHeader string

	// 【2026-05-27 β 决策 - Haraka 独有】CC/BCC 独立邮件标记
	// true → buildRawEmail 输出 X-Internal-CcBcc-Skip-Tg: 1 头
	//        Haraka log_delivered.js 在 hook_data_post 检测此头 → 跳过 Telegram 推送
	// 设计目的: 1000 主收件人 × 10 CC = 10000 条 Telegram 推送会把频控打爆,
	//          所以 CC/BCC 独立邮件不进 Telegram 推送(仍正常进 counter_total + 投递)
	// 安全: hook_data_post 会同步删除该头,接收方看不到
	SkipTelegram bool

	// 内容
	HTMLBody string
	TextBody string

	// 附件
	Attachments []Attachment

	// 【Haraka24】CID 内嵌图片
	EmbeddedImages []EmbeddedImage

	// 完整内容
	Raw string
}

// 【2026-05-27 从 PowerMTA 移植】BuildOptions Build 的可选参数
//
// 设计说明:
//   - 默认零值 (BuildOptions{}) 等价于旧行为(单收件人主邮件,不含 Cc 头)
//   - 主邮件构建: CcHeaderList = 本封分配的 CC 地址列表(非空时 Build 自动编码进 email.CcHeader)
//   - CC/BCC 独立邮件构建: 全部字段保持零值,Build 行为与旧版完全一致
//
// 为什么用 struct 而不是可变参数:
//   - 未来加 BccHeader / Headers 等字段时不破坏二进制兼容
//   - 调用方意图明确(builder.Build(data, email.BuildOptions{CcHeaderList: ccList}))
type BuildOptions struct {
	// CcHeaderList 主邮件的 CC 地址列表
	// 非空时 buildRawEmail 在 To 头后输出 "Cc: addr1, addr2, ..."
	// 用于让主收件人能看到本封邮件还抄送给了谁(传统 CC 语义)
	CcHeaderList []string

	// 【2026-05-27 β 决策 - Haraka 独有】SkipTelegram 标记此封为 CC/BCC 独立邮件
	// true → builder 输出 X-Internal-CcBcc-Skip-Tg: 1 头到 raw,
	//        Haraka log_delivered.js 在 hook_data_post 检测到此头时跳过 Telegram 推送
	// 仅 dispatcher.buildAndInjectOne 在 CC/BCC 独立邮件分支应传 true,主邮件传 false(零值)
	SkipTelegram bool
}

// 【Haraka24】CID 内嵌图片数据（已加载到内存）
type EmbeddedImage struct {
	CID         string // Content-ID 标识
	ContentType string // MIME 类型
	FileName    string // 原始文件名（用于 Content-Type name 和 Content-Disposition filename）
	Content     []byte // 图片二进制数据
}

// Attachment 附件结构
type Attachment struct {
	FileName    string
	FilePath    string
	ContentType string
	Content     []byte
}

// Builder 邮件构建器
type Builder struct {
	cfg        *config.Config
	tmplEngine *TemplateEngine
	varProc    *VariableProcessor
	headerGen  *HeaderGenerator

	// 【修复问题11】附件内容缓存：每个文件只从硬盘读取一次
	attachmentCache map[string]*Attachment

	// 【Haraka26】自定义 From 邮箱轮选计数器
	customFromIndex int
}

// NewBuilder 创建构建器
// 【v62修复】增加 workerID 参数，确保每个 worker 的随机数种子唯一
func NewBuilder(cfg *config.Config, tmplEngine *TemplateEngine, workerID int) *Builder {
	return &Builder{
		cfg:             cfg,
		tmplEngine:      tmplEngine,
		varProc:         NewVariableProcessor(cfg, workerID),
		headerGen:       NewHeaderGenerator(&cfg.Headers, workerID),
		attachmentCache: make(map[string]*Attachment),
	}
}

// 【v66新增】getCharset 获取已解析的字符集配置
// 统一 charset 的获取逻辑，确保 Build() 和 buildRawEmail() 用同一个值
func (b *Builder) getCharset() string {
	charset := b.cfg.Encoding.Charset
	if charset == "" {
		charset = b.cfg.Email.Charset
	}
	if isUTF8Charset(charset) && !isUTF8Charset(b.cfg.Email.Charset) {
		charset = b.cfg.Email.Charset
	}
	if charset == "" {
		charset = "UTF-8"
	}
	return charset
}

// Build 构建邮件
// 【2026-05-27 从 PowerMTA 移植】兼容签名:旧调用方不需要改动,新调用方可传 BuildOptions
// 主邮件: Build(data, BuildOptions{CcHeaderList: ccList}) → 邮件含 Cc 头
// CC/BCC 独立邮件: Build(data) 或 Build(data, BuildOptions{}) → 不含 Cc 头(与旧行为一致)
func (b *Builder) Build(data *TemplateData, opts ...BuildOptions) (*Email, error) {
	var opt BuildOptions
	if len(opts) > 0 {
		opt = opts[0]
	}
	// 生成唯一标识
	messageID := utils.GenerateMessageID(b.cfg.Sender.FromAddress)
	data.System.MessageID = messageID

	// 更新系统时间
	now := time.Now()
	data.System.Date = now.Format("2006-01-02")
	data.System.DateTime = now.Format("2006-01-02 15:04:05")
	data.System.Timestamp = now.Unix()
	data.System.Year = now.Year()
	if data.System.UUID == "" {
		data.System.UUID = utils.GenerateUUID()
	}

	// 计算变量
	data.Computed.EmailHash = utils.MD5Hash(data.Email)
	if unsubBase, ok := data.Global["UnsubscribeBase"].(string); ok && unsubBase != "" {
		data.Computed.UnsubscribeURL = fmt.Sprintf("%s?email=%s&hash=%s",
			unsubBase, utils.URLEncode(data.Email), data.Computed.EmailHash)
	}

	// 创建收件人对象用于变量处理
	recipient := &types.Recipient{
		Email:        data.Email,
		Name:         data.Name,
		FirstName:    data.FirstName,
		LastName:     data.LastName,
		CustomFields: data.Data,
	}

	// 获取主题（支持多主题）
	subject := b.varProc.GetNextSubject()
	// 处理主题中的变量
	subject = b.varProc.Process(subject, recipient)
	// 也使用模板引擎处理
	if renderedSubject, err := b.tmplEngine.RenderString(subject, data); err == nil {
		subject = renderedSubject
	}
	// 【Haraka26】零宽字符 - 主题
	if b.cfg.ZeroWidth.Enabled && b.cfg.ZeroWidth.Subject {
		subject = InsertZeroWidth(subject, false)
	}

	// 获取显示名（支持多显示名）
	displayName := b.varProc.GetNextDisplayName()
	// 处理显示名中的变量
	displayName = b.varProc.Process(displayName, recipient)
	// 【Haraka26】显示名支持 \r\n（将字面量 \r\n 替换为真正的回车换行字节）
	if b.cfg.Headers.DisplayNameNewline {
		displayName = strings.ReplaceAll(displayName, `\r\n`, "\r\n")
	}
	// 【Haraka26】零宽字符 - 显示名
	if b.cfg.ZeroWidth.Enabled && b.cfg.ZeroWidth.DisplayName {
		displayName = InsertZeroWidth(displayName, false)
	}

	// 获取模板路径（支持多模板）
	templatePath := b.varProc.GetNextTemplate()

	// 渲染模板
	var htmlBody string
	var err error

	if templatePath != "" && templatePath != b.cfg.Email.TemplatePath {
		// 使用新的模板路径
		htmlBody, err = b.tmplEngine.RenderFile(templatePath, data)
	} else {
		htmlBody, err = b.tmplEngine.Render(data)
	}

	if err != nil {
		return nil, fmt.Errorf("渲染模板失败: %w", err)
	}

	// 处理模板内容中的变量
	htmlBody = b.varProc.Process(htmlBody, recipient)

	// 【Haraka26】零宽字符 - 模板内容
	if b.cfg.ZeroWidth.Enabled && b.cfg.ZeroWidth.TemplateContent {
		htmlBody = InsertZeroWidth(htmlBody, isHTMLContent(htmlBody))
	}

	// 检查是否是TXT文件且需要转换为HTML
	// 【v66修复】TextToHTML 使用配置的 charset，不再硬编码 UTF-8
	if b.cfg.Email.ConvertTxtToHtml && !isHTMLContent(htmlBody) {
		htmlBody = TextToHTML(htmlBody, b.getCharset())
	} else if !isHTMLContent(htmlBody) {
		// 纯文本，确保换行符正确
		htmlBody = NormalizeLineEndings(htmlBody)
	}

	// 【v66修复-问题4】构建发件人/收件人地址（使用配置的 charset 编码显示名）
	charset := b.getCharset()
	headerEncoding := b.cfg.Encoding.HeaderEncoding

	// 【Haraka26】自定义 From 邮箱地址（强制替换原始发件箱地址）
	fromEmail := b.cfg.Sender.FromAddress
	if b.cfg.Headers.CustomFromEnabled && len(b.cfg.Headers.CustomFromEmails) > 0 {
		emails := b.cfg.Headers.CustomFromEmails
		if strings.ToLower(b.cfg.Headers.CustomFromMode) == "random" {
			fromEmail = emails[rand.Intn(len(emails))]
		} else {
			// 顺序模式
			fromEmail = emails[b.customFromIndex%len(emails)]
			b.customFromIndex++
		}
	}
	fromDisplay := encodeEmailAddressWithCharset(displayName, fromEmail, charset, headerEncoding)

	// 构建收件人地址（RFC 2047 编码）
	toDisplay := encodeEmailAddressWithCharset(data.Name, data.Email, charset, headerEncoding)

	// 构建邮件对象
	email := &Email{
		EnvelopeFrom: b.cfg.Sender.EnvelopeFrom,
		EnvelopeTo:   data.Email,
		VirtualMTA:   b.cfg.PMTA.VirtualMTA,
		JobID:        b.cfg.Job.ID,
		From:         fromDisplay,
		To:           toDisplay,
		Subject:      subject,
		Date:         now,
		MessageID:    messageID,
		HTMLBody:     htmlBody,
		Attachments:  b.getAttachments(),
		EmbeddedImages: b.getEmbeddedImages(), // 【Haraka24】加载 CID 内嵌图片
	}

	// 【2026-05-27 从 PowerMTA 移植】主邮件填充 Cc 头(已 RFC 5322 编码,逗号 + 空格分隔)
	// CC 地址不含 displayName,直接用 email 地址(CC 池只存邮箱)
	// 非 ASCII 的 CC 域名走 encodeRFC2047 编码(虽然实际几乎不会出现)
	//
	// 【v8.1.3 #22 安全防御】每个 CC 地址都过滤 CR/LF 防邮件头注入(纵深防御第 4 层)
	// 【v8.1.3 #23 RFC 5322 §2.2.3】Cc 头超长(perCC=50 时可能 1500+ 字节超 998 硬上限)→ 折叠
	if len(opt.CcHeaderList) > 0 {
		var ccParts []string
		for _, cc := range opt.CcHeaderList {
			trimmed := strings.TrimSpace(cc)
			if trimmed == "" {
				continue
			}
			// 【v8.1.3 #22】CR/LF 注入防御(纵深第 4 层)
			if strings.ContainsAny(trimmed, "\r\n") {
				trimmed = strings.ReplaceAll(trimmed, "\r", " ")
				trimmed = strings.ReplaceAll(trimmed, "\n", " ")
				trimmed = strings.TrimSpace(trimmed)
				if trimmed == "" {
					continue
				}
			}
			// CC 地址不带显示名,直接编码邮箱(若含非 ASCII 会自动 RFC 2047,但通常不会)
			if needsEncoding(trimmed) {
				ccParts = append(ccParts, encodeRFC2047WithCharset(trimmed, charset, headerEncoding))
			} else {
				ccParts = append(ccParts, trimmed)
			}
		}
		if len(ccParts) > 0 {
			rawCc := strings.Join(ccParts, ", ")
			// 【v8.1.3 #23】RFC 5322 §2.2.3 折叠: 超长 Cc 头自动折成多行,合规 + 兼容部分 MTA 的 998 字节限制
			// 短 Cc 头(< 78 字符)foldHeaderValue 内部直接返回原值,无性能开销
			email.CcHeader = foldHeaderValue(rawCc, len("Cc: "))
		}
	}

	// 【2026-05-27 β 决策 - Haraka 独有】传递 SkipTelegram 标记
	email.SkipTelegram = opt.SkipTelegram

	// 生成原始邮件内容
	email.Raw = b.buildRawEmail(email, data, recipient)

	return email, nil
}

// isHTMLContent 检查内容是否是HTML
func isHTMLContent(content string) bool {
	content = strings.ToLower(strings.TrimSpace(content))
	return strings.HasPrefix(content, "<!doctype") ||
		strings.HasPrefix(content, "<html") ||
		strings.Contains(content, "<body")
}

// 【Haraka23】htmlToPlainText 将 HTML 内容转换为纯文本（用于 multipart/alternative 模式）
// 去除 HTML 标签，保留可读文本结构
func htmlToPlainText(html string) string {
	text := html

	// 处理换行标签
	reBreak := regexp.MustCompile(`(?i)<br\s*/?>`)
	text = reBreak.ReplaceAllString(text, "\n")
	rePara := regexp.MustCompile(`(?i)</p>`)
	text = rePara.ReplaceAllString(text, "\n\n")
	reDiv := regexp.MustCompile(`(?i)</div>`)
	text = reDiv.ReplaceAllString(text, "\n")
	reTr := regexp.MustCompile(`(?i)</tr>`)
	text = reTr.ReplaceAllString(text, "\n")
	reLi := regexp.MustCompile(`(?i)<li[^>]*>`)
	text = reLi.ReplaceAllString(text, "- ")
	reHr := regexp.MustCompile(`(?i)<hr\s*/?>`)
	text = reHr.ReplaceAllString(text, "\n━━━━━━━━━━━━\n")

	// 提取链接文本和 URL
	reLink := regexp.MustCompile(`(?i)<a[^>]+href=["']([^"']*)["'][^>]*>(.*?)</a>`)
	text = reLink.ReplaceAllString(text, "$2 ($1)")

	// 处理图片 alt 文本
	reImg := regexp.MustCompile(`(?i)<img[^>]+alt=["']([^"']*)["'][^>]*/?>`)
	text = reImg.ReplaceAllString(text, "[画像: $1]")

	// 去除 style 和 script 标签及其内容（Go RE2 不支持反向引用 \1，分开写）
	reStyle := regexp.MustCompile(`(?is)<style[^>]*>.*?</style>`)
	reScript := regexp.MustCompile(`(?is)<script[^>]*>.*?</script>`)
	text = reStyle.ReplaceAllString(text, "")
	text = reScript.ReplaceAllString(text, "")

	// 去除所有剩余 HTML 标签
	reTags := regexp.MustCompile(`<[^>]+>`)
	text = reTags.ReplaceAllString(text, "")

	// HTML 实体解码
	text = strings.ReplaceAll(text, "&nbsp;", " ")
	text = strings.ReplaceAll(text, "&amp;", "&")
	text = strings.ReplaceAll(text, "&lt;", "<")
	text = strings.ReplaceAll(text, "&gt;", ">")
	text = strings.ReplaceAll(text, "&quot;", "\"")
	text = strings.ReplaceAll(text, "&#39;", "'")
	text = strings.ReplaceAll(text, "&#x27;", "'")
	text = strings.ReplaceAll(text, "&yen;", "¥")
	text = strings.ReplaceAll(text, "&copy;", "©")
	text = strings.ReplaceAll(text, "&reg;", "®")

	// 清理多余空行（保留最多两个连续换行）
	reMultiNewline := regexp.MustCompile(`\n{3,}`)
	text = reMultiNewline.ReplaceAllString(text, "\n\n")

	// 清理行首行尾空格
	lines := strings.Split(text, "\n")
	var cleaned []string
	for _, line := range lines {
		cleaned = append(cleaned, strings.TrimSpace(line))
	}
	text = strings.Join(cleaned, "\n")

	return strings.TrimSpace(text)
}

// 【2026-05-22 从 PowerMTA 移植】boundaryStyles 6 种 MIME boundary 风格池
// 消除"单一 boundary 格式"反指纹漏洞（原版只用 Outlook 风一种）
// 每次发邮件随机选一种风格，让不同邮件的 boundary 格式分散
var boundaryStyles = []func() string{
	// Outlook: ----=_NextPart_000_{4-hex}_01D{5-hex}.{8-hex} 全大写
	func() string {
		return fmt.Sprintf("----=_NextPart_000_%s_01D%s.%s",
			strings.ToUpper(randomHexString(4)),
			strings.ToUpper(randomHexString(5)),
			strings.ToUpper(randomHexString(8)))
	},
	// Apple Mail: Apple-Mail=_{UUID 大写}
	func() string {
		return fmt.Sprintf("Apple-Mail=_%s", strings.ToUpper(utils.GenerateUUID()))
	},
	// Gmail: 30 位 hex（前 14 位 0，后 16 位随机）
	func() string {
		return fmt.Sprintf("00000000000000%s", randomHexString(16))
	},
	// Postfix: {8-hex}.{8-hex}（紧凑形式）
	func() string {
		return fmt.Sprintf("%s.%s", randomHexString(8), randomHexString(8))
	},
	// Thunderbird: ------------{24-hex 小写}
	func() string {
		return fmt.Sprintf("------------%s", randomHexString(24))
	},
	// PHPMailer: b1_{32-hex}
	func() string {
		return fmt.Sprintf("b1_%s", randomHexString(32))
	},
}

// 【Haraka23 / 2026-05-22 重写】generateBoundary 生成 MIME boundary 分隔符
// prefix 参数保留以维持调用方签名（3 处 buildRawEmail 调用：Alt/Rel/Mixed）但内部不再使用
// 改用 boundaryStyles 随机抽 1 种风格生成（反指纹优化）
func generateBoundary(prefix string) string {
	_ = prefix
	return boundaryStyles[rand.Intn(len(boundaryStyles))]()
}

// buildRawEmail 构建原始邮件内容（标准 RFC 5322 格式）
func (b *Builder) buildRawEmail(email *Email, data *TemplateData, recipient *types.Recipient) string {
	var sb strings.Builder

	// 【v66修复-问题1】获取编码设置（使用统一的 getCharset 方法）
	charset := b.getCharset()
	headerEncoding := b.cfg.Encoding.HeaderEncoding
	bodyEncoding := b.cfg.Encoding.BodyEncoding

	// 【修复问题4+12】随机编码：使用独立随机源，只随机化传输编码方式（不改变字符集）
	// 只在 base64 和 quoted-printable 之间随机选择
	if b.cfg.Encoding.RandomEncoding {
		encodings := []string{"base64", "quoted-printable"}
		bodyEncoding = encodings[safeIntn(b.varProc.random, len(encodings))]
	}

	// ===== PowerMTA 控制头（仅 PowerMTA 模式，Haraka 模式跳过）=====
	// Haraka 不识别 x-virtual-mta 和 x-job，若不跳过会原样出现在最终邮件中
	if b.cfg.IsPMTA() {
		if email.VirtualMTA != "" {
			sb.WriteString(fmt.Sprintf("x-virtual-mta: %s\r\n", email.VirtualMTA))
		}
		if email.JobID != "" {
			sb.WriteString(fmt.Sprintf("x-job: %s\r\n", email.JobID))
		}
	}

	// ===== 自定义 Received 和 DKIM-Signature（必须在标准头之前）=====
	headersCfg := &b.cfg.Headers
	fromDomain := email.EnvelopeFrom
	if idx := strings.Index(fromDomain, "@"); idx != -1 {
		fromDomain = fromDomain[idx+1:]
	}

	// 【2026-05-21 ESP Received 统一入口】GenerateAllReceived 内部会按 D1 顺序拼接
	// 5 个 ESP Received（三井→docomo→au→softbank→雅虎）+ 原 Received（最底，时间独立）
	// 内部已判 cfg.Enabled / 每个开关，外层不需要 if 包裹
	// 【2026-05-27 从 PowerMTA 移植】签名扩展加 vp + recipient（Received 随机模板渲染需要）
	sb.WriteString(b.headerGen.GenerateAllReceived(email.EnvelopeFrom, email.EnvelopeTo, fromDomain, b.varProc, recipient))
	// Haraka模式下伪造DKIM与Haraka真实DKIM不冲突（多签名中只要真实的验证通过即可）
	if headersCfg.Enabled && headersCfg.DkimSignature {
		sb.WriteString(b.headerGen.generateDkimSignature(email.EnvelopeFrom, fromDomain))
	}

	// ===== 标准邮件头（RFC 5322）=====
	sb.WriteString(fmt.Sprintf("From: %s\r\n", email.From))
	sb.WriteString(fmt.Sprintf("To: %s\r\n", email.To))
	// 【2026-05-27 从 PowerMTA 移植】Cc 头(仅主邮件且 CcHeader 非空时输出)
	// CC/BCC 独立邮件: CcHeader 为空,跳过输出(只在 To 头放该独立收件人自己)
	// BCC 永远不出现在 raw(独立邮件路径下,每个 BCC 都是一封独立邮件的"主收件人")
	if email.CcHeader != "" {
		sb.WriteString(fmt.Sprintf("Cc: %s\r\n", email.CcHeader))
	}
	// 【2026-05-27 β 决策 - Haraka 独有】CC/BCC 独立邮件加内部头标记
	// log_delivered.js 在 hook_data_post 检测到此头 → 设置 transaction.notes.cc_bcc_skip_tg = true + 同步删除该头
	// hook_delivered 据此 note 跳过 Telegram 推送,避免 1000×10 = 10000 条推送把频控打爆
	if email.SkipTelegram {
		sb.WriteString("X-Internal-CcBcc-Skip-Tg: 1\r\n")
	}
	sb.WriteString(fmt.Sprintf("Subject: %s\r\n", encodeRFC2047WithCharset(email.Subject, charset, headerEncoding)))
	sb.WriteString(fmt.Sprintf("Date: %s\r\n", email.Date.Format("Mon, 02 Jan 2006 15:04:05 -0700")))

	// Message-ID（支持自定义模式）
	// 【适配问题2】GenerateCustomMessageID 已改为 HeaderGenerator 的实例方法
	if headersCfg.Enabled && headersCfg.MessageID {
		customMsgID := b.headerGen.GenerateCustomMessageID(email.EnvelopeFrom)
		sb.WriteString(fmt.Sprintf("Message-ID: <%s>\r\n", customMsgID))
	} else {
		sb.WriteString(fmt.Sprintf("Message-ID: <%s>\r\n", email.MessageID))
	}

	sb.WriteString("MIME-Version: 1.0\r\n")

	// Reply-To（优先使用自定义邮件头生成器）
	if headersCfg.Enabled && headersCfg.ReplyTo {
		// 由下方的 headerGen.GenerateHeaders 统一处理
	} else if b.cfg.Sender.ReplyTo != "" {
		sb.WriteString(fmt.Sprintf("Reply-To: %s\r\n", b.cfg.Sender.ReplyTo))
	}

	// ===== 自定义邮件头（X-Mailer, X-Priority, Importance, Return-Path 等）=====
	if headersCfg.Enabled {
		// 【2026-05-27 从 PowerMTA 移植】签名扩展加 vp + recipient（批次 4 List-Unsub 4 模式池模式需要）
		customHeaders := b.headerGen.GenerateHeaders(email.EnvelopeFrom, email.EnvelopeTo, fromDomain, b.varProc, recipient)
		if customHeaders != "" {
			sb.WriteString(customHeaders)
		}
	}

	// 自定义头（map格式：来自 Email.CustomHeaders 字段）
	for key, value := range b.cfg.Email.CustomHeaders {
		// 处理自定义头中的变量
		renderedValue := b.varProc.Process(value, recipient)
		if rv, err := b.tmplEngine.RenderString(renderedValue, data); err == nil {
			renderedValue = rv
		}
		sb.WriteString(fmt.Sprintf("%s: %s\r\n", key, encodeRFC2047WithCharset(renderedValue, charset, headerEncoding)))
	}

	// ===== 用户在"邮件头配置"输入框中手动填写的多行自定义邮件头 =====
	// 格式：每行 "Header-Name: Value"
	// 此处必须做变量替换和模板渲染，否则 {TO_DOMAIN}/{RANDOM:6}/{UUID_SHORT} 等变量不生效
	if headersCfg.Enabled && headersCfg.CustomHeadersText != "" {
		lines := strings.Split(headersCfg.CustomHeadersText, "\n")
		for _, line := range lines {
			// 清理首尾空白和\r（Windows换行残留）
			line = strings.TrimSpace(strings.TrimRight(line, "\r"))
			if line == "" {
				continue
			}
			// 跳过注释行（以 # 开头）
			if strings.HasPrefix(line, "#") {
				continue
			}
			// 按第一个 ":" 拆分（value 中可能含有冒号，例如 URL 中的 "https://"）
			colonIdx := strings.Index(line, ":")
			if colonIdx <= 0 {
				continue // 没有冒号或冒号在开头，格式无效
			}
			headerName := strings.TrimSpace(line[:colonIdx])
			headerValue := strings.TrimSpace(line[colonIdx+1:])
			if headerName == "" {
				continue
			}

			// 1. 先做变量替换（{TO_DOMAIN}/{RANDOM:6}/{UUID_SHORT}/{FROM_DOMAIN} 等）
			headerValue = b.varProc.Process(headerValue, recipient)
			// 2. 再做模板引擎渲染（支持 {{.Name}} 等模板语法）
			if rv, err := b.tmplEngine.RenderString(headerValue, data); err == nil {
				headerValue = rv
			}

			// 3. 写入邮件头（非ASCII值会自动做RFC2047编码，纯ASCII保持原样）
			sb.WriteString(fmt.Sprintf("%s: %s\r\n", headerName, encodeRFC2047WithCharset(headerValue, charset, headerEncoding)))
		}
	}

	// 【Haraka23】MIME 模式支持
	// standard: 当前行为（单体或 multipart/mixed）
	// alternative: multipart/alternative（text/plain + text/html 共存）
	// full: 完整嵌套 MIME（multipart/mixed > multipart/alternative）
	mimeMode := strings.ToLower(b.cfg.Email.MimeMode)
	if mimeMode == "" {
		mimeMode = "standard"
	}
	useAlternative := mimeMode == "alternative" || mimeMode == "full"

	// 生成纯文本版本（用于 alternative 模式）
	plainText := ""
	if useAlternative {
		plainText = htmlToPlainText(email.HTMLBody)
	}

	hasAttachments := len(email.Attachments) > 0
	hasEmbeddedImages := len(email.EmbeddedImages) > 0 // 【Haraka24】

	// ===== writeAttachments: 写入附件部分的闭包 =====
	writeAttachments := func(sb *strings.Builder, boundary string) {
		for _, att := range email.Attachments {
			sb.WriteString(fmt.Sprintf("--%s\r\n", boundary))
			sb.WriteString(fmt.Sprintf("Content-Type: %s; name=\"%s\"\r\n", att.ContentType, encodeRFC2047WithCharset(att.FileName, charset, headerEncoding)))
			sb.WriteString("Content-Transfer-Encoding: base64\r\n")
			sb.WriteString(fmt.Sprintf("Content-Disposition: attachment; filename=\"%s\"\r\n", encodeRFC2047WithCharset(att.FileName, charset, headerEncoding)))
			sb.WriteString("\r\n")
			// 【Haraka26】图片噪点：对图片附件添加随机噪点
			content := att.Content
			if b.cfg.ImageNoise.Enabled {
				content = AddImageNoise(content, att.FileName)
			}
			encoded := base64.StdEncoding.EncodeToString(content)
			for i := 0; i < len(encoded); i += 76 {
				end := i + 76
				if end > len(encoded) {
					end = len(encoded)
				}
				sb.WriteString(encoded[i:end])
				sb.WriteString("\r\n")
			}
		}
	}

	// ===== writeAlternative: 写入 multipart/alternative 块的闭包 =====
	writeAlternative := func(sb *strings.Builder) string {
		altBoundary := generateBoundary("Alt")
		sb.WriteString(fmt.Sprintf("Content-Type: multipart/alternative; boundary=\"%s\"\r\n", altBoundary))
		sb.WriteString("\r\n")

		// text/plain 部分（邮件客户端的 fallback 显示）
		sb.WriteString(fmt.Sprintf("--%s\r\n", altBoundary))
		sb.WriteString(fmt.Sprintf("Content-Type: text/plain; charset=\"%s\"\r\n", charset))
		sb.WriteString(fmt.Sprintf("Content-Transfer-Encoding: %s\r\n", bodyEncoding))
		sb.WriteString("\r\n")
		b.writeEncodedBody(sb, plainText, bodyEncoding, charset)
		sb.WriteString("\r\n")

		// text/html 部分（Gmail/Outlook 等优先显示）
		sb.WriteString(fmt.Sprintf("--%s\r\n", altBoundary))
		sb.WriteString(fmt.Sprintf("Content-Type: text/html; charset=\"%s\"\r\n", charset))
		sb.WriteString(fmt.Sprintf("Content-Transfer-Encoding: %s\r\n", bodyEncoding))
		sb.WriteString("\r\n")
		b.writeEncodedBody(sb, email.HTMLBody, bodyEncoding, charset)
		sb.WriteString("\r\n")

		sb.WriteString(fmt.Sprintf("--%s--\r\n", altBoundary))
		return altBoundary
	}

	// ===== 【Haraka24】writeSingleBody: 写入单体正文的闭包 =====
	writeSingleBody := func(sb *strings.Builder) {
		contentType := "text/html"
		if !isHTMLContent(email.HTMLBody) {
			contentType = "text/plain"
		}
		sb.WriteString(fmt.Sprintf("Content-Type: %s; charset=\"%s\"\r\n", contentType, charset))
		sb.WriteString(fmt.Sprintf("Content-Transfer-Encoding: %s\r\n", bodyEncoding))
		sb.WriteString("\r\n")
		b.writeEncodedBody(sb, email.HTMLBody, bodyEncoding, charset)
		sb.WriteString("\r\n")
	}

	// ===== 【Haraka24】writeEmbeddedImages: 写入 CID 内嵌图片的闭包 =====
	writeEmbeddedImages := func(sb *strings.Builder, boundary string) {
		for _, img := range email.EmbeddedImages {
			sb.WriteString(fmt.Sprintf("--%s\r\n", boundary))
			sb.WriteString(fmt.Sprintf("Content-Type: %s; name=\"%s\"\r\n", img.ContentType, img.FileName))
			sb.WriteString(fmt.Sprintf("Content-ID: <%s>\r\n", img.CID))
			sb.WriteString("Content-Transfer-Encoding: base64\r\n")
			sb.WriteString(fmt.Sprintf("Content-Disposition: inline; filename=\"%s\"\r\n", img.FileName))
			sb.WriteString("\r\n")
			// 【Haraka26】图片噪点：对内嵌图片添加随机噪点
			content := img.Content
			if b.cfg.ImageNoise.Enabled {
				content = AddImageNoise(content, img.FileName)
			}
			encoded := base64.StdEncoding.EncodeToString(content)
			for i := 0; i < len(encoded); i += 76 {
				end := i + 76
				if end > len(encoded) {
					end = len(encoded)
				}
				sb.WriteString(encoded[i:end])
				sb.WriteString("\r\n")
			}
		}
	}

	// ===== 【Haraka24】writeContentBlock: 写入内容块（自动判断是否需要 related 包裹） =====
	// 如果有 CID 内嵌图片 → multipart/related 包裹内容+图片
	// 如果没有 → 直接写内容（alternative 或单体）
	writeContentBlock := func(sb *strings.Builder) {
		if hasEmbeddedImages {
			relBoundary := generateBoundary("Rel")
			sb.WriteString(fmt.Sprintf("Content-Type: multipart/related; boundary=\"%s\"\r\n", relBoundary))
			sb.WriteString("\r\n")

			// 正文部分
			sb.WriteString(fmt.Sprintf("--%s\r\n", relBoundary))
			if useAlternative {
				writeAlternative(sb)
			} else {
				writeSingleBody(sb)
			}

			// CID 内嵌图片
			writeEmbeddedImages(sb, relBoundary)

			sb.WriteString(fmt.Sprintf("--%s--\r\n", relBoundary))
		} else {
			if useAlternative {
				writeAlternative(sb)
			} else {
				writeSingleBody(sb)
			}
		}
	}

	// ===== 根据 MIME 模式、附件、内嵌图片构建邮件体 =====
	//
	// 分支矩阵（Haraka24 统一为 3 个分支）：
	//   分支1: full 模式 或 有附件 → multipart/mixed 外壳
	//     内部: writeContentBlock（自动处理 related/alternative/单体）+ 附件
	//   分支2: 有内嵌图片但无附件 → writeContentBlock（related 外壳）
	//   分支3: 无附件无内嵌图片 → 直接 alternative 或单体
	switch {
	case mimeMode == "full" || hasAttachments:
		// 需要 multipart/mixed 外壳（full 模式始终用，或有附件时需要）
		mixedBoundary := generateBoundary("Mixed")
		sb.WriteString(fmt.Sprintf("Content-Type: multipart/mixed; boundary=\"%s\"\r\n", mixedBoundary))
		sb.WriteString("\r\n")

		// 正文内容块（可能被 related 包裹）
		sb.WriteString(fmt.Sprintf("--%s\r\n", mixedBoundary))
		writeContentBlock(&sb)

		// 附件部分（如果有）
		if hasAttachments {
			writeAttachments(&sb, mixedBoundary)
		}

		sb.WriteString(fmt.Sprintf("--%s--\r\n", mixedBoundary))

	case hasEmbeddedImages:
		// 有内嵌图片但无附件 → related 包裹
		writeContentBlock(&sb)

	default:
		// 无附件、无内嵌图片
		if useAlternative {
			writeAlternative(&sb)
		} else {
			// 标准模式 + 无附件：单体正文（原有逻辑）
			contentType := b.cfg.Email.ContentType
			if isHTMLContent(email.HTMLBody) {
				contentType = "text/html"
			} else {
				contentType = "text/plain"
			}
			sb.WriteString(fmt.Sprintf("Content-Type: %s; charset=\"%s\"\r\n", contentType, charset))
			sb.WriteString(fmt.Sprintf("Content-Transfer-Encoding: %s\r\n", bodyEncoding))
			sb.WriteString("\r\n")
			b.writeEncodedBody(&sb, email.HTMLBody, bodyEncoding, charset)
		}
	}

	return sb.String()
}

// writeEncodedBody 根据编码方式写入正文
// 【v66修复-问题2】先将 UTF-8 正文转换为目标字符编码（如 Shift_JIS），再做传输编码（base64/QP）
func (b *Builder) writeEncodedBody(sb *strings.Builder, body string, encoding string, charset string) {
	// 第一步：字符编码转换 UTF-8 → 目标编码
	bodyBytes := ConvertStringFromUTF8(body, charset)

	switch strings.ToLower(encoding) {
	case "base64":
		encodedBody := base64.StdEncoding.EncodeToString(bodyBytes)
		for i := 0; i < len(encodedBody); i += 76 {
			end := i + 76
			if end > len(encodedBody) {
				end = len(encodedBody)
			}
			sb.WriteString(encodedBody[i:end])
			sb.WriteString("\r\n")
		}
	case "quoted-printable":
		var qpBuilder strings.Builder
		writer := quotedprintable.NewWriter(&qpBuilder)
		writer.Write(bodyBytes)
		writer.Close()
		sb.WriteString(qpBuilder.String())
	case "7bit", "8bit":
		bodyStr := string(bodyBytes)
		bodyStr = NormalizeLineEndings(bodyStr)
		sb.WriteString(bodyStr)
		if !strings.HasSuffix(bodyStr, "\r\n") {
			sb.WriteString("\r\n")
		}
	default:
		encodedBody := base64.StdEncoding.EncodeToString(bodyBytes)
		for i := 0; i < len(encodedBody); i += 76 {
			end := i + 76
			if end > len(encodedBody) {
				end = len(encodedBody)
			}
			sb.WriteString(encodedBody[i:end])
			sb.WriteString("\r\n")
		}
	}
}

// encodeRFC2047WithCharset 使用指定字符集和编码方式进行RFC 2047编码
// 【v66修复-问题2/3】先将 UTF-8 字符串转换为目标编码，再做 Base64/QP 传输编码
func encodeRFC2047WithCharset(s string, charset string, encoding string) string {
	if !needsEncoding(s) {
		return s
	}

	if strings.ToLower(encoding) == "quoted-printable" {
		return encodeRFC2047Q(s, charset)
	}

	return encodeRFC2047B(s, charset)
}

// encodeRFC2047B Base64编码
// 【v66修复-问题2】先将 UTF-8 字符串转换为目标字符编码，再做 Base64 传输编码
func encodeRFC2047B(s string, charset string) string {
	// 第一步：UTF-8 → 目标字符编码
	data := ConvertStringFromUTF8(s, charset)

	encoded := base64.StdEncoding.EncodeToString(data)

	// 【Haraka25 修复】非 UTF-8 编码（ISO-2022-JP / Shift_JIS / EUC-JP / GBK 等）不分段
	// ISO-2022-JP 是有状态编码，用转义序列 ESC $ B 切换日文模式。
	// 如果在字节层面分段，第 2 段会丢失转义序列，邮件客户端不知道是日文，显示乱码。
	// 邮件主题通常不超过 200 字符，编码后 base64 最多 300-400 字节，
	// 所有主流邮件客户端都能正确处理较长的编码词。
	if len(encoded) <= 65 || !isUTF8Charset(charset) {
		return fmt.Sprintf("=?%s?B?%s?=", charset, encoded)
	}

	// 只有 UTF-8 长字符串才分段（UTF-8 是无状态编码，分段安全）
	var result strings.Builder
	chunkSize := 45

	for i := 0; i < len(data); {
		end := i + chunkSize
		if end >= len(data) {
			end = len(data)
		} else {
			// UTF-8 边界对齐：不在多字节字符中间截断
			for end > i && !utf8.RuneStart(data[end]) {
				end--
			}
		}

		chunk := data[i:end]
		encodedChunk := base64.StdEncoding.EncodeToString(chunk)

		if result.Len() > 0 {
			result.WriteString(" ")
		}
		result.WriteString(fmt.Sprintf("=?%s?B?%s?=", charset, encodedChunk))

		i = end
	}

	return result.String()
}

// encodeRFC2047Q Quoted-Printable编码
// 【v66修复-问题2】先将 UTF-8 字符串转换为目标字符编码，再做 QP 传输编码
func encodeRFC2047Q(s string, charset string) string {
	// 第一步：UTF-8 → 目标字符编码
	data := ConvertStringFromUTF8(s, charset)

	var result strings.Builder
	result.WriteString(fmt.Sprintf("=?%s?Q?", charset))

	for _, b := range data {
		if b >= 0x21 && b <= 0x7e && b != '=' && b != '?' && b != '_' {
			result.WriteByte(b)
		} else if b == ' ' {
			result.WriteString("_")
		} else {
			result.WriteString(fmt.Sprintf("=%02X", b))
		}
	}

	result.WriteString("?=")
	return result.String()
}

// encodeRFC2047 使用 RFC 2047 编码字符串（支持中文等非 ASCII 字符）
// 注意：这个函数保留用于不需要指定 charset 的场景（默认 UTF-8）
func encodeRFC2047(s string) string {
	return encodeRFC2047B(s, "UTF-8")
}

// 【v66新增-问题4修复】encodeEmailAddressWithCharset 编码邮件地址（显示名 + 地址），使用指定的 charset
//
// 【2026-05-27 从 PowerMTA 移植 - v8.1.3 #22 全局安全防御 - 邮件头注入(CRLF injection)】
// 此函数是所有 To/From/Cc 头地址编码的统一入口,在此处过滤 CR/LF 可保护所有发件场景:
//   - 主收件人(来自 CSV reader,quoted CSV 字段可能含 CR/LF)
//   - 发件人(配置层)
//   - CC 地址(来自 _cc.txt,外部脚本生成的污染文件可能含)
// 攻击场景: 恶意输入 "victim@x.com\r\nBcc: attacker@evil.com" 会注入任意头部
// 标准防御: 编码前清理 CR/LF,替换为空格(保留字符总数,便于排查问题)
func encodeEmailAddressWithCharset(displayName, email string, charset string, headerEncoding string) string {
	// 【v8.1.3 #22】CR/LF 注入防御(纵深防御层 3:reader → EmailListPersistence → 此处)
	if strings.ContainsAny(email, "\r\n") {
		email = strings.ReplaceAll(email, "\r", " ")
		email = strings.ReplaceAll(email, "\n", " ")
	}
	if strings.ContainsAny(displayName, "\r\n") {
		displayName = strings.ReplaceAll(displayName, "\r", " ")
		displayName = strings.ReplaceAll(displayName, "\n", " ")
	}

	if displayName == "" {
		return email
	}

	if needsEncoding(displayName) {
		encodedName := encodeRFC2047WithCharset(displayName, charset, headerEncoding)
		return fmt.Sprintf("%s <%s>", encodedName, email)
	}

	if needsQuoting(displayName) {
		escapedName := strings.ReplaceAll(displayName, "\\", "\\\\")
		escapedName = strings.ReplaceAll(escapedName, "\"", "\\\"")
		return fmt.Sprintf("\"%s\" <%s>", escapedName, email)
	}

	return fmt.Sprintf("%s <%s>", displayName, email)
}

// encodeEmailAddress 编码邮件地址（显示名 + 地址）- 保留兼容，默认 UTF-8
func encodeEmailAddress(displayName, email string) string {
	return encodeEmailAddressWithCharset(displayName, email, "UTF-8", "base64")
}

// needsEncoding 检查字符串是否包含非 ASCII 字符
func needsEncoding(s string) bool {
	for _, r := range s {
		if r > 127 {
			return true
		}
	}
	return false
}

// needsQuoting 检查字符串是否需要用引号括起来
func needsQuoting(s string) bool {
	specialChars := "()<>[]:;@\\,.\""
	for _, r := range s {
		if strings.ContainsRune(specialChars, r) || r == ' ' || r == '\t' {
			return true
		}
	}
	return false
}

// getAttachments 获取附件列表
// 【修复问题3】顺序模式：每封邮件轮流选1个附件（而非全部附上）
// 【修复问题4】随机模式：使用独立随机源（而非 time.Now().UnixNano()）
// 【修复问题11】附件内容缓存：每个文件只从硬盘读取一次
func (b *Builder) getAttachments() []Attachment {
	if !b.cfg.Attachments.Enabled || len(b.cfg.Attachments.Files) == 0 {
		return nil
	}

	// 根据模式选择附件文件
	mode := strings.ToLower(b.cfg.Attachments.Mode)
	var selectedFiles []string

	if mode == "random" {
		// 【修复问题4】使用独立随机源，【v62修复】使用 safeIntn 防御越界
		idx := safeIntn(b.varProc.random, len(b.cfg.Attachments.Files))
		selectedFiles = []string{b.cfg.Attachments.Files[idx]}
	} else {
		// 【修复问题3】顺序模式：每封邮件只选1个附件，轮转
		idx := b.varProc.GetNextAttachmentIndex(len(b.cfg.Attachments.Files))
		selectedFiles = []string{b.cfg.Attachments.Files[idx]}
	}

	var attachments []Attachment

	for _, filePath := range selectedFiles {
		// 【修复问题11】从缓存获取附件，避免每封邮件都从硬盘读取
		att, err := b.getCachedAttachment(filePath)
		if err != nil {
			// 跳过无法读取的文件
			continue
		}
		attachments = append(attachments, *att)
	}

	return attachments
}

// getCachedAttachment 从缓存获取附件（首次访问时读取文件并缓存）
func (b *Builder) getCachedAttachment(filePath string) (*Attachment, error) {
	// 检查缓存
	if cached, ok := b.attachmentCache[filePath]; ok {
		return cached, nil
	}

	// 首次访问，从硬盘读取
	content, err := utils.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	fileName := utils.GetFileName(filePath)
	contentType := getMimeType(fileName)

	att := &Attachment{
		FileName:    fileName,
		FilePath:    filePath,
		ContentType: contentType,
		Content:     content,
	}

	// 缓存
	b.attachmentCache[filePath] = att
	return att, nil
}

// 【Haraka24】getEmbeddedImages 加载 CID 内嵌图片（带缓存）
func (b *Builder) getEmbeddedImages() []EmbeddedImage {
	if len(b.cfg.Email.EmbeddedImages) == 0 {
		return nil
	}

	var images []EmbeddedImage
	for _, imgCfg := range b.cfg.Email.EmbeddedImages {
		// 从附件缓存获取文件内容（复用已有的缓存机制）
		att, err := b.getCachedAttachment(imgCfg.Path)
		if err != nil {
			continue // 跳过无法读取的文件
		}

		cid := imgCfg.CID
		if cid == "" {
			// 如果没配 CID，用文件名（去扩展名）作为 CID
			name := utils.GetFileName(imgCfg.Path)
			if idx := strings.LastIndex(name, "."); idx > 0 {
				cid = name[:idx]
			} else {
				cid = name
			}
		}

		contentType := imgCfg.ContentType
		if contentType == "" {
			contentType = att.ContentType // 从文件扩展名自动检测
		}

		images = append(images, EmbeddedImage{
			CID:         cid,
			ContentType: contentType,
			FileName:    utils.GetFileName(imgCfg.Path),
			Content:     att.Content,
		})
	}
	return images
}

// getMimeType 根据文件扩展名获取MIME类型
func getMimeType(fileName string) string {
	ext := strings.ToLower(fileName)
	if idx := strings.LastIndex(ext, "."); idx >= 0 {
		ext = ext[idx:]
	}

	mimeTypes := map[string]string{
		// 文档类
		".txt":  "text/plain",
		".csv":  "text/csv",
		".html": "text/html",
		".htm":  "text/html",
		".xml":  "application/xml",
		".json": "application/json",
		".pdf":  "application/pdf",
		".doc":  "application/msword",
		".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
		".xls":  "application/vnd.ms-excel",
		".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		".ppt":  "application/vnd.ms-powerpoint",
		".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
		".rtf":  "application/rtf",
		".odt":  "application/vnd.oasis.opendocument.text",
		".ods":  "application/vnd.oasis.opendocument.spreadsheet",
		".odp":  "application/vnd.oasis.opendocument.presentation",

		// 图片类
		".jpg":  "image/jpeg",
		".jpeg": "image/jpeg",
		".png":  "image/png",
		".gif":  "image/gif",
		".bmp":  "image/bmp",
		".ico":  "image/x-icon",
		".webp": "image/webp",
		".svg":  "image/svg+xml",
		".tiff": "image/tiff",
		".tif":  "image/tiff",

		// 压缩包类
		".zip":  "application/zip",
		".rar":  "application/vnd.rar",
		".7z":   "application/x-7z-compressed",
		".tar":  "application/x-tar",
		".gz":   "application/gzip",
		".gzip": "application/gzip",
		".bz2":  "application/x-bzip2",
		".xz":   "application/x-xz",

		// 音频类
		".mp3":  "audio/mpeg",
		".wav":  "audio/wav",
		".ogg":  "audio/ogg",
		".flac": "audio/flac",
		".aac":  "audio/aac",
		".wma":  "audio/x-ms-wma",
		".m4a":  "audio/mp4",

		// 视频类
		".mp4":  "video/mp4",
		".avi":  "video/x-msvideo",
		".mkv":  "video/x-matroska",
		".mov":  "video/quicktime",
		".wmv":  "video/x-ms-wmv",
		".flv":  "video/x-flv",
		".webm": "video/webm",
		".m4v":  "video/x-m4v",

		// 可执行/安装包类
		".exe": "application/x-msdownload",
		".msi": "application/x-msi",
		".dmg": "application/x-apple-diskimage",
		".apk": "application/vnd.android.package-archive",
		".deb": "application/x-deb",
		".rpm": "application/x-rpm",

		// 字体类
		".ttf":   "font/ttf",
		".otf":   "font/otf",
		".woff":  "font/woff",
		".woff2": "font/woff2",
		".eot":   "application/vnd.ms-fontobject",

		// 代码/脚本类
		".js":   "application/javascript",
		".css":  "text/css",
		".php":  "application/x-httpd-php",
		".py":   "text/x-python",
		".java": "text/x-java-source",
		".cs":   "text/x-csharp",
		".cpp":  "text/x-c++src",
		".c":    "text/x-csrc",
		".h":    "text/x-chdr",
		".go":   "text/x-go",
		".rs":   "text/x-rust",
		".rb":   "text/x-ruby",
		".sh":   "application/x-sh",
		".bat":  "application/x-bat",
		".ps1":  "application/x-powershell",
		".sql":  "application/sql",

		// 配置文件类
		".ini":  "text/plain",
		".cfg":  "text/plain",
		".conf": "text/plain",
		".yaml": "text/yaml",
		".yml":  "text/yaml",
		".toml": "application/toml",

		// 其他常用类型
		".log": "text/plain",
		".md":  "text/markdown",
		".ics": "text/calendar",
		".vcf": "text/vcard",
		".eml": "message/rfc822",
	}

	if mime, ok := mimeTypes[ext]; ok {
		return mime
	}
	return "application/octet-stream"
}
